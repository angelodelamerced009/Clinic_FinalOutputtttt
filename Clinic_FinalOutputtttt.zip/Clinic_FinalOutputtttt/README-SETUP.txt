SCHOOL CLINIC MANAGEMENT SYSTEM  -  PHP + MySQL
=================================================
Ang HTML, CSS (css/style.css) at itsura ng system ay HINDI ginalaw. Ang mga .html ay naging .php (parehong markup),
ang JavaScript ay hinati bawat function, at lahat ng data ay naka-save na sa MySQL.

1. I-COPY ang BUONG folder na ito sa C:\xampp\htdocs\clinic  (kumpleto na: pages, api, css\style.css, js\main.js)
   - js\main.js = LAHAT ng JavaScript sa iisang file (may "=====" na label bawat function)
   - js-split-reference-not-used\ = ang hiwa-hiwalay na version (bawat function = isang file). Hindi ito ginagamit; para sa basa lang.
     Kung gusto mo ito ang gamitin: ilagay ang laman nito sa js\ (palitan ang main.js).
   - puwede nang burahin ang mga luma mong includes\header.php, includes\footer.php, css\clinic.css
2. Start Apache + MySQL sa XAMPP.
3. DATABASE (phpMyAdmin)
   a) http://localhost/phpmyadmin -> Import -> database.sql -> Go     (gagawa ng school_clinic_db + 5 tables)
   b) (optional) Import -> sample-data.sql                            (9 sample students/records, isang beses lang)
   Kung hindi ka mag-import, gagawin din ito ng PHP awtomatiko sa unang bukas ng system.
4. Kung may password ang MySQL mo, ilagay sa config.php (DB_PASS).
5. Buksan: http://localhost/clinic/    Login: Doctor mreyes / doctor123   Nurse acruz / nurse123

TABLES                      GINAGAMIT NG
users                       Login, Profile, Change password (last_login)
students                    Student Records
medical_records             Medical records, Record Status, Clearance Approval, Record Analysis
inquiries                   "Contact admin" at "Forgot password" sa login page
activity_logs               login/logout, add/update/delete, status change, approve/reject, password, inquiry
(Dashboard statistics = COUNT queries sa medical_records; Recent Activity = huling 5 sa activity_logs)

PHP FILES (api/ folder, isang file = isang gawain, kapareho ng JS action)
config.php                  database connection (DB_HOST/DB_NAME/DB_USER/DB_PASS), auto-create ng tables, session
api/common.php             shared helpers + validation
api/login.php               A.login        api/record-save.php      A.save
api/data.php                loadData()     api/record-delete.php    A.del
api/record-move.php         A.move         api/clearance-decide.php A.decide
api/password-change.php     A.pw           api/inquiry-submit.php   A.inquirySend
logout.php                  A.logout (page mismo ang nagla-log out)

JAVASCRIPT (js/ folder; isang function = isang file; js/main.js ang naglo-load ng lahat sa tamang order)
core/       constants.js, icons.js, state.js
helpers/    select-element ($), escape-html (E), capitalize (cap), date-string (dstr), time-format (tm),
            is-doctor (isDoc), option-list (opts), notice, status-badge (st)
data/       api-request.js (api), load-data.js (loadData)                     <- bago, pumalit sa localStorage
views/      draw, login-view, inquiry-modal, shell, dashboard, rows-html, records, form, status, clearance,
            analyse, analysis, profile, view-modal, wire-board
actions/    action-object (const A) + nav, role, hint, login, logout, filter, add, view, close-view, edit, del,
            save, move, pick, decide, pw, inquiry-open, inquiry-close, inquiry-send
start.js    ang dating dulo ng main.js (pageName, pageViews, flash, simula ng app)

BINAGO SA JS (kasi MySQL na ang pinagkukunan; lahat ng ibang function ay kapareho ng orihinal)
- login, logout, del, save, move, decide, pw  -> tumatawag na sa api/*.php (may "// MYSQL:" comment sa taas)
- dashboard   -> stats at Recent Activity galing sa MySQL
- login-view  -> "Contact admin"/"Forgot password" ay nagbubukas na ng inquiry form (dating A.hint; nandoon pa rin ang A.hint)
- nav / start -> .html naging .php
- TINANGGAL (napalitan ng MySQL): seed(), load(), save(), pwOf(), USERS, lastLogin at ang localStorage na data

PAALALA: may dalawang pagbabago sa Student No. -> 2 letra + 9 numero (hal. CA202400125), ginawang uppercase;
ang sample data ay gumagamit na ng ganitong format. Ang mga inquiry ay makikita sa phpMyAdmin > inquiries table.
