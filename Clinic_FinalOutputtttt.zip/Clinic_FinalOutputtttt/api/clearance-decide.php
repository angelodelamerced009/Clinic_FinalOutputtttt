<?php
// MEDICAL CLEARANCE APPROVAL (doctor lang): approve o reject + doctor's remarks.
require_once __DIR__ . '/common.php';
$in = api_input();
if (!is_doctor()) throw new ApiError('Only a doctor can approve or reject clearance.', 403);
$pdo = db();
$id = (int)($in['id'] ?? 0);
$approve = ($in['approve'] ?? false) === true;
$note = s($in, 'remarks');
if (mb_strlen($note) > 2000) throw new ApiError('Remarks are too long (up to 2000 characters).');
if (!$approve && $note === '') throw new ApiError('Add your remarks before rejecting, so the nurse knows what to fix.');
$q = $pdo->prepare('SELECT m.id, m.status, m.test_type, s.full_name FROM medical_records m JOIN students s ON s.id = m.student_id WHERE m.id = ?');
$q->execute([$id]);
$r = $q->fetch();
if (!$r) throw new ApiError('That record no longer exists.', 404);
if ($r['status'] === 'approved') throw new ApiError('This record is already approved.', 409);
$pdo->prepare('UPDATE medical_records SET doctor_remarks = ?, status = ?, updated_by = ?, updated_at = NOW() WHERE id = ?')
    ->execute([$note, $approve ? 'approved' : 'pending', (int)$_SESSION['user']['id'], $id]);
if ($approve) log_activity($pdo, 'approved', $r['full_name'] . "'s " . $r['test_type'] . ' approved', $id);
else log_activity($pdo, 'rejected', $r['full_name'] . "'s " . $r['test_type'] . ' rejected, sent back to pending', $id);
out(['ok' => true]);
