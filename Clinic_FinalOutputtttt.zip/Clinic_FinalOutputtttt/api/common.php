<?php
// Shared helpers ng lahat ng api/*.php (lahat ng sagot ay JSON).
define('API_MODE', true);
require_once __DIR__ . '/../config.php';
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

// Dapat kapareho ng TESTS / YEARS / ST sa js/core/constants.js
const TESTS = ['Physical Exam', 'Blood Test', 'X-Ray', 'Immunization', 'Dental Check-up', 'Vision Screening'];
const YEARS = ['Year 1', 'Year 2', 'Year 3', 'Year 4'];
const MED_STATUSES = ['pending', 'ongoing', 'approved'];

class ApiError extends Exception {}

function out(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}
function fail(string $message, int $code = 400): void { out(['ok' => false, 'error' => $message], $code); }

set_exception_handler(function (Throwable $e) {
    if ($e instanceof ApiError) fail($e->getMessage(), $e->getCode() ?: 400);
    error_log('[clinic api] ' . $e);
    fail('Server error. Please try again.', 500);
});

// POST + JSON lang. Kailangan ng login at CSRF token (maliban sa login at inquiry).
function api_input(bool $needLogin = true, bool $needCsrf = true): array {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') fail('POST required.', 405);
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) fail('JSON required.', 415);
    if ($needLogin && empty($_SESSION['user'])) fail('Your session expired. Please log in again.', 401);
    if ($needCsrf) {
        $t = $_SESSION['csrf'] ?? '';
        if ($t === '' || !hash_equals($t, $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) fail('Invalid request. Please refresh the page and try again.', 403);
    }
    $d = json_decode(file_get_contents('php://input'), true);
    return is_array($d) ? $d : [];
}
// Kunin ang text field (trimmed). Hindi tinatanggap ang array/object.
function s(array $in, string $key): string {
    $v = $in[$key] ?? '';
    return is_scalar($v) ? trim((string)$v) : '';
}
function nz(string $v): ?string { return $v === '' ? null : $v; }
function num_or_null(string $v, float $min, float $max, string $label): ?float {
    if ($v === '') return null;
    if (!is_numeric($v) || (float)$v < $min || (float)$v > $max) throw new ApiError("$label must be a number from $min to $max.");
    return (float)$v;
}

// Isang medical record + estudyante, sa hugis na ginagamit ng JavaScript.
const RECORD_SELECT = "SELECT m.id, s.student_no AS `no`, s.full_name AS `name`, s.year_level AS `year`, s.course,
        m.test_type AS `test`, DATE_FORMAT(m.exam_date, '%Y-%m-%d') AS `date`, m.status, m.remarks,
        m.doctor_remarks AS `dr`, m.height_cm AS `height`, m.weight_kg AS `weight`, m.blood_pressure AS `bp`,
        m.heart_rate AS `hr`, m.vision, m.hearing, UNIX_TIMESTAMP(m.updated_at) * 1000 AS `t`
    FROM medical_records m JOIN students s ON s.id = m.student_id";
function fmt_record(array $r): array {
    return [
        'id' => (int)$r['id'], 'no' => (string)$r['no'], 'name' => (string)$r['name'], 'year' => (string)$r['year'],
        'course' => (string)$r['course'], 'test' => (string)$r['test'], 'date' => (string)$r['date'], 'status' => (string)$r['status'],
        'remarks' => (string)($r['remarks'] ?? ''), 'dr' => (string)($r['dr'] ?? ''),
        'height' => $r['height'] === null ? null : (float)$r['height'], 'weight' => $r['weight'] === null ? null : (float)$r['weight'],
        'bp' => (string)($r['bp'] ?? ''), 'hr' => $r['hr'] === null ? null : (int)$r['hr'],
        'vision' => (string)($r['vision'] ?? ''), 'hearing' => (string)($r['hearing'] ?? ''), 't' => (int)$r['t'],
    ];
}
// Burahin ang estudyante kapag wala na siyang kahit isang medical record.
function delete_orphan_student(PDO $pdo, int $studentId): void {
    $pdo->prepare('DELETE FROM students WHERE id = ? AND NOT EXISTS (SELECT 1 FROM medical_records WHERE student_id = ?)')
        ->execute([$studentId, $studentId]);
}
