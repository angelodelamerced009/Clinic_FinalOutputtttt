<?php
// DASHBOARD STATISTICS + lahat ng records para sa pages. Binabasa ng js/data/load-data.js.
require_once __DIR__ . '/common.php';
$pdo = db(); // kumonekta agad: dito nagagawa ang database at mga table sa unang bukas ng system
if (empty($_SESSION['user'])) out(['ok' => true, 'user' => null]);

$q = $pdo->prepare('SELECT username, full_name, role, email, phone FROM users WHERE id = ?');
$q->execute([$_SESSION['user']['id']]);
$u = $q->fetch();
if (!$u) { $_SESSION = []; out(['ok' => true, 'user' => null]); }

$y = (int)($_GET['year'] ?? date('Y')); $m = (int)($_GET['month'] ?? date('n'));
if ($y < 2000 || $y > 2100 || $m < 1 || $m > 12) { $y = (int)date('Y'); $m = (int)date('n'); }
$from = sprintf('%04d-%02d-01', $y, $m);
$to = date('Y-m-d', strtotime($from . ' +1 month'));

$counts = ['pending' => 0, 'ongoing' => 0, 'approved' => 0]; $total = 0;
foreach ($pdo->query('SELECT status, COUNT(*) AS c FROM medical_records GROUP BY status') as $r) {
    $counts[$r['status']] = (int)$r['c']; $total += (int)$r['c'];
}
$cal = [];
$q = $pdo->prepare('SELECT DAY(exam_date) AS d, COUNT(*) AS c FROM medical_records WHERE exam_date >= ? AND exam_date < ? GROUP BY DAY(exam_date)');
$q->execute([$from, $to]);
foreach ($q as $r) $cal[(int)$r['d']] = (int)$r['c'];

$rows = array_map('fmt_record', $pdo->query(RECORD_SELECT . ' ORDER BY m.id')->fetchAll());

$activity = [];
foreach ($pdo->query("SELECT action, description, UNIX_TIMESTAMP(created_at) * 1000 AS t FROM activity_logs
        WHERE action IN ('record_added','record_updated','record_deleted','status_changed','approved','rejected')
        ORDER BY id DESC LIMIT 5") as $r) {
    $activity[] = ['action' => $r['action'], 'description' => $r['description'], 't' => (int)$r['t']];
}

out(['ok' => true, 'csrf' => csrf_token(),
    'user' => ['name' => $u['full_name'], 'role' => strtolower($u['role']), 'user' => $u['username'],
               'email' => (string)$u['email'], 'phone' => (string)$u['phone'], 'last' => $_SESSION['prev_login'] ?? null],
    'rows' => $rows,
    'stats' => ['total' => $total, 'counts' => $counts, 'calendar' => (object)$cal],
    'activity' => $activity]);
