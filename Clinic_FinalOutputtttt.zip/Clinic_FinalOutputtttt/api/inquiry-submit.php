<?php
// INQUIRIES -> inquiries table ("Contact admin" at "Forgot password" sa login page; hindi kailangan ng login).
require_once __DIR__ . '/common.php';
$in = api_input(false, false);
$pdo = db();
if (time() - (int)($_SESSION['inquiry_at'] ?? 0) < 10) throw new ApiError('Please wait a few seconds before sending another message.', 429);
$type = in_array(s($in, 'type'), ['access', 'password'], true) ? s($in, 'type') : 'general';
$name = s($in, 'name'); $email = s($in, 'email'); $message = s($in, 'message');
if ($name === '' || mb_strlen($name) > 100) throw new ApiError('Please enter your name (up to 100 characters).');
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 100) throw new ApiError('Please enter a valid email address.');
if ($message === '' || mb_strlen($message) > 2000) throw new ApiError('Please enter your message (up to 2000 characters).');
$pdo->prepare('INSERT INTO inquiries (name, email, type, message) VALUES (?,?,?,?)')->execute([$name, $email, $type, $message]);
$_SESSION['inquiry_at'] = time();
log_activity($pdo, 'inquiry_sent', 'Inquiry (' . $type . ') received from ' . $name);
out(['ok' => true]);
