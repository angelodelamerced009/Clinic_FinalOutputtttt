<?php
// HEALTH INSIGHTS: kinukuha ng PHP ang records sa MySQL, ipinapasa sa python/analytics.py, ibinabalik ang JSON.
require_once __DIR__ . '/common.php';
if (empty($_SESSION['user'])) fail('Your session expired. Please log in again.', 401);

$PYTHON = 'python';   // kung hindi gumana: buong path, hal. 'C:\\Python312\\python.exe'
$script = realpath(__DIR__ . '/../python/analytics.py');
if (!$script) fail('analytics.py not found.', 500);

$pdo  = db();
$rows = array_map('fmt_record', $pdo->query(RECORD_SELECT . ' ORDER BY m.id')->fetchAll());

$proc = proc_open([$PYTHON, $script],
    [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
if (!is_resource($proc)) fail('Cannot start Python.', 500);

fwrite($pipes[0], json_encode($rows)); fclose($pipes[0]);
$out = stream_get_contents($pipes[1]);
$err = stream_get_contents($pipes[2]);
fclose($pipes[1]); fclose($pipes[2]);
$code = proc_close($proc);

if ($code !== 0 || $out === '') {
    error_log('[clinic python] ' . $err);
    fail('Python error. Check that Python is installed and in PATH.', 500);
}
echo $out;
