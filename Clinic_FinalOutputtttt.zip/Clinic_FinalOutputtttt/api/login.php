<?php
// LOGIN -> users table. Isinusulat din sa activity_logs ang bawat login / failed login.
require_once __DIR__ . '/common.php';
$in = api_input(false, false);
$pdo = db();
$username = s($in, 'username');
$password = is_string($in['password'] ?? null) ? $in['password'] : '';
$roleSel = strtolower(s($in, 'role'));
$ip = $_SERVER['REMOTE_ADDR'] ?? '';

$q = $pdo->prepare("SELECT COUNT(*) FROM activity_logs WHERE action = 'login_failed' AND ip_address = ? AND created_at > (NOW() - INTERVAL 15 MINUTE)");
$q->execute([$ip]);
if ((int)$q->fetchColumn() >= 10) throw new ApiError('Too many failed attempts. Please wait 15 minutes and try again.', 429);

$q = $pdo->prepare('SELECT id, username, password, full_name, role, email, phone, UNIX_TIMESTAMP(last_login) * 1000 AS last_ms FROM users WHERE username = ?');
$q->execute([$username]);
$u = $q->fetch();
if (!$u || !password_verify($password, $u['password']) || strtolower($u['role']) !== $roleSel) {
    log_activity($pdo, 'login_failed', "Failed login for '" . $username . "'", null, mb_substr($username, 0, 50));
    throw new ApiError('The username, password, or role is incorrect.', 401);
}

session_regenerate_id(true);
unset($_SESSION['csrf']);
$_SESSION['user'] = ['id' => (int)$u['id'], 'username' => $u['username'], 'full_name' => $u['full_name'], 'role' => $u['role']];
$_SESSION['prev_login'] = $u['last_ms'] === null ? null : (int)$u['last_ms'];
$pdo->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$u['id']]);
log_activity($pdo, 'login', $u['full_name'] . ' logged in');

out(['ok' => true, 'csrf' => csrf_token(), 'user' => [
    'name' => $u['full_name'], 'role' => strtolower($u['role']), 'user' => $u['username'],
    'email' => (string)$u['email'], 'phone' => (string)$u['phone'], 'last' => $_SESSION['prev_login'],
]]);
