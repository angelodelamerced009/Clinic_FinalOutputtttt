<?php
// CHANGE PASSWORD -> users table (naka-hash gamit password_hash).
require_once __DIR__ . '/common.php';
$in = api_input();
$pdo = db();
$current = is_string($in['current'] ?? null) ? $in['current'] : '';
$new = is_string($in['password'] ?? null) ? $in['password'] : '';
$q = $pdo->prepare('SELECT password FROM users WHERE id = ?');
$q->execute([$_SESSION['user']['id']]);
if (!password_verify($current, (string)$q->fetchColumn())) throw new ApiError('Your current password is incorrect.');
if (strlen($new) < 8) throw new ApiError('New password must be at least 8 characters.');
$pdo->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user']['id']]);
log_activity($pdo, 'password_changed', $_SESSION['user']['full_name'] . ' changed their password');
out(['ok' => true]);
