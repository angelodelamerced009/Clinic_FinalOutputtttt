<?php
// DELETE medical record (doctor lang). Binubura rin ang estudyante kung wala na siyang record.
require_once __DIR__ . '/common.php';
$in = api_input();
if (!is_doctor()) throw new ApiError('Only a doctor can delete records.', 403);
$pdo = db();
$id = (int)($in['id'] ?? 0);
$pdo->beginTransaction();
try {
    $q = $pdo->prepare('SELECT m.id, m.student_id, m.test_type, s.full_name FROM medical_records m JOIN students s ON s.id = m.student_id WHERE m.id = ? FOR UPDATE');
    $q->execute([$id]);
    $r = $q->fetch();
    if (!$r) throw new ApiError('That record no longer exists.', 404);
    $pdo->prepare('DELETE FROM medical_records WHERE id = ?')->execute([$id]);
    delete_orphan_student($pdo, (int)$r['student_id']);
    log_activity($pdo, 'record_deleted', $r['full_name'] . "'s " . $r['test_type'] . ' record deleted', $id);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}
out(['ok' => true]);
