<?php
// RECORD STATUS (pending / ongoing / approved). Nurse ay hindi puwedeng mag-approve o gumalaw ng approved.
require_once __DIR__ . '/common.php';
$in = api_input();
$pdo = db();
$id = (int)($in['id'] ?? 0);
$to = s($in, 'status');
if (!in_array($to, MED_STATUSES, true)) throw new ApiError('Please choose a valid status.');
$q = $pdo->prepare('SELECT m.id, m.status, m.test_type, s.full_name FROM medical_records m JOIN students s ON s.id = m.student_id WHERE m.id = ?');
$q->execute([$id]);
$r = $q->fetch();
if (!$r) throw new ApiError('That record no longer exists.', 404);
if (!is_doctor() && ($to === 'approved' || $r['status'] === 'approved')) throw new ApiError('Only a doctor can approve records or change approved ones.', 403);
if ($r['status'] !== $to) {
    $pdo->prepare('UPDATE medical_records SET status = ?, updated_by = ?, updated_at = NOW() WHERE id = ?')->execute([$to, (int)$_SESSION['user']['id'], $id]);
    if ($to === 'approved') log_activity($pdo, 'approved', $r['full_name'] . "'s " . $r['test_type'] . ' approved', $id);
    else log_activity($pdo, 'status_changed', $r['full_name'] . "'s " . $r['test_type'] . ' moved to ' . $to, $id);
}
out(['ok' => true]);
