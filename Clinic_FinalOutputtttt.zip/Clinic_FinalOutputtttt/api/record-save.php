<?php
// STUDENT RECORDS + MEDICAL RECORDS -> students at medical_records tables (add o update).
require_once __DIR__ . '/common.php';
$in = api_input();
$pdo = db();
$id = (int)($in['id'] ?? 0);   // 0 = bagong record
$f = [];
foreach (['no', 'name', 'year', 'course', 'test', 'date', 'status', 'remarks', 'height', 'weight', 'bp', 'hr', 'vision', 'hearing'] as $k) $f[$k] = s($in, $k);
$f['no'] = strtoupper($f['no']);

if (!preg_match('/^[A-Z]{2}\d{9}$/', $f['no'])) throw new ApiError('Student No. must be 2 letters + 9 digits (example: CA202505407).');
if ($f['name'] === '' || mb_strlen($f['name']) > 100) throw new ApiError('Please enter the student name (up to 100 characters).');
if (!in_array($f['year'], YEARS, true)) throw new ApiError('Please choose a valid year level.');
if ($f['course'] === '' || mb_strlen($f['course']) > 50) throw new ApiError('Please enter the course (up to 50 characters).');
if (!in_array($f['test'], TESTS, true)) throw new ApiError('Please choose a valid kind of test.');
$d = DateTime::createFromFormat('Y-m-d', $f['date']);
if (!$d || $d->format('Y-m-d') !== $f['date']) throw new ApiError('Please enter a valid date of exam.');
if (!in_array($f['status'], MED_STATUSES, true)) throw new ApiError('Please choose a valid status.');
if (mb_strlen($f['remarks']) > 2000) throw new ApiError('Remarks are too long (up to 2000 characters).');
$height = num_or_null($f['height'], 50, 250, 'Height');
$weight = num_or_null($f['weight'], 10, 300, 'Weight');
$hrNum  = num_or_null($f['hr'], 30, 220, 'Heart rate');
$hr     = $hrNum === null ? null : (int)round($hrNum);
if ($f['bp'] !== '' && !preg_match('/^\d{2,3}\/\d{2,3}$/', $f['bp'])) throw new ApiError('Blood pressure must look like 110/70.');
if ($f['vision'] !== '' && !preg_match('/^\d{1,2}\/\d{1,3}$/', $f['vision'])) throw new ApiError('Vision must look like 20/20.');
if (mb_strlen($f['hearing']) > 50) throw new ApiError('Hearing is too long (up to 50 characters).');

$uid = (int)$_SESSION['user']['id'];
$pdo->beginTransaction();
try {
    $old = null;
    if ($id) {
        $q = $pdo->prepare('SELECT * FROM medical_records WHERE id = ? FOR UPDATE');
        $q->execute([$id]);
        $old = $q->fetch();
        if (!$old) throw new ApiError('That record no longer exists.', 404);
        if ($old['status'] === 'approved' && !is_doctor()) throw new ApiError('Only a doctor can edit an approved record.', 403);
    }
    if ($f['status'] === 'approved' && !is_doctor()) throw new ApiError('Only a doctor can mark a record as approved.', 403);

    // 1) students table
    $q = $pdo->prepare('SELECT * FROM students WHERE student_no = ? FOR UPDATE');
    $q->execute([$f['no']]);
    $stu = $q->fetch();
    if ($stu) {
        $own = $old && (int)$old['student_id'] === (int)$stu['id'];
        if (!$own && mb_strtolower($stu['full_name']) !== mb_strtolower($f['name'])) {
            throw new ApiError('Student No. ' . $f['no'] . ' is already registered to ' . $stu['full_name'] . '.', 409);
        }
        $pdo->prepare('UPDATE students SET full_name = ?, year_level = ?, course = ? WHERE id = ?')
            ->execute([$f['name'], $f['year'], $f['course'], $stu['id']]);
        $sid = (int)$stu['id'];
    } else {
        $count = 0;
        if ($old) {
            $q = $pdo->prepare('SELECT COUNT(*) FROM medical_records WHERE student_id = ?');
            $q->execute([$old['student_id']]);
            $count = (int)$q->fetchColumn();
        }
        if ($old && $count === 1) {   // tama lang ang maling Student No. ng iisang record niya
            $pdo->prepare('UPDATE students SET student_no = ?, full_name = ?, year_level = ?, course = ? WHERE id = ?')
                ->execute([$f['no'], $f['name'], $f['year'], $f['course'], $old['student_id']]);
            $sid = (int)$old['student_id'];
        } else {
            $pdo->prepare('INSERT INTO students (student_no, full_name, year_level, course) VALUES (?,?,?,?)')
                ->execute([$f['no'], $f['name'], $f['year'], $f['course']]);
            $sid = (int)$pdo->lastInsertId();
        }
    }

    // 2) medical_records table
    $vals = [$sid, $f['test'], $f['date'], $f['status'], $f['remarks'], $height, $weight, nz($f['bp']), $hr, nz($f['vision']), nz($f['hearing'])];
    if ($old) {
        $pdo->prepare('UPDATE medical_records SET student_id = ?, test_type = ?, exam_date = ?, status = ?, remarks = ?, height_cm = ?, weight_kg = ?,
                blood_pressure = ?, heart_rate = ?, vision = ?, hearing = ?, updated_by = ?, updated_at = NOW() WHERE id = ?')
            ->execute(array_merge($vals, [$uid, $id]));
        $rid = $id;
        if ((int)$old['student_id'] !== $sid) delete_orphan_student($pdo, (int)$old['student_id']);
    } else {
        $pdo->prepare('INSERT INTO medical_records (student_id, test_type, exam_date, status, remarks, height_cm, weight_kg,
                blood_pressure, heart_rate, vision, hearing, created_by, updated_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
            ->execute(array_merge($vals, [$uid, $uid]));
        $rid = (int)$pdo->lastInsertId();
    }

    // 3) activity_logs table
    $approvedNow = $f['status'] === 'approved' && (!$old || $old['status'] !== 'approved');
    $action = $approvedNow ? 'approved' : ($old ? 'record_updated' : 'record_added');
    $verb = $approvedNow ? 'approved' : ($old ? 'record updated' : 'record added');
    log_activity($pdo, $action, $f['name'] . "'s " . $f['test'] . ' ' . $verb, $rid);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}
out(['ok' => true, 'id' => $rid]);
