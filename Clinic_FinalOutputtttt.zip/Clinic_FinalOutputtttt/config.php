<?php
// ---- Edit these to match your MySQL (XAMPP default shown) ----
const DB_HOST = 'localhost';
const DB_NAME = 'school_clinic_db';
const DB_USER = 'root';
const DB_PASS = '';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}


function detect_base_url(): string {
    $doc = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
    $app = realpath(__DIR__) ?: '';
    $doc = rtrim(str_replace('\\', '/', $doc), '/');
    $app = rtrim(str_replace('\\', '/', $app), '/');
    if ($doc !== '' && stripos($app, $doc) === 0) {
        $rel = trim(substr($app, strlen($doc)), '/');
        return $rel === '' ? '/' : '/' . implode('/', array_map('rawurlencode', explode('/', $rel))) . '/';
    }
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $dir . '/';
}
define('BASE_URL', detect_base_url());

function install_schema(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        role ENUM('Doctor','Nurse') NOT NULL,
        email VARCHAR(100) NULL,
        phone VARCHAR(30) NULL,
        last_login TIMESTAMP NULL DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB");
    // Kung luma ang users table (galing sa lumang version), idagdag ang kulang na columns.
    $have = array_map('strtolower', $pdo->query("SELECT column_name FROM information_schema.columns
            WHERE table_schema = DATABASE() AND table_name = 'users'")->fetchAll(PDO::FETCH_COLUMN));
    if (!in_array('email', $have, true))      $pdo->exec('ALTER TABLE users ADD COLUMN email VARCHAR(100) NULL');
    if (!in_array('phone', $have, true))      $pdo->exec('ALTER TABLE users ADD COLUMN phone VARCHAR(30) NULL');
    if (!in_array('last_login', $have, true)) $pdo->exec('ALTER TABLE users ADD COLUMN last_login TIMESTAMP NULL DEFAULT NULL');

    $pdo->exec("CREATE TABLE IF NOT EXISTS students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_no VARCHAR(20) NOT NULL UNIQUE,
        full_name VARCHAR(100) NOT NULL,
        year_level VARCHAR(20) NOT NULL,
        course VARCHAR(50) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_students_name (full_name)) ENGINE=InnoDB");
    $pdo->exec("CREATE TABLE IF NOT EXISTS medical_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        test_type VARCHAR(50) NOT NULL,
        exam_date DATE NOT NULL,
        status ENUM('pending','ongoing','approved') NOT NULL DEFAULT 'pending',
        remarks TEXT NULL,
        doctor_remarks TEXT NULL,
        height_cm DECIMAL(5,1) NULL,
        weight_kg DECIMAL(5,1) NULL,
        blood_pressure VARCHAR(10) NULL,
        heart_rate SMALLINT UNSIGNED NULL,
        vision VARCHAR(10) NULL,
        hearing VARCHAR(50) NULL,
        created_by INT NULL,
        updated_by INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_med_student (student_id), INDEX idx_med_status (status), INDEX idx_med_date (exam_date),
        CONSTRAINT fk_med_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB");
    $pdo->exec("CREATE TABLE IF NOT EXISTS inquiries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        type ENUM('access','password','general') NOT NULL DEFAULT 'general',
        message TEXT NOT NULL,
        status ENUM('new','read','resolved') NOT NULL DEFAULT 'new',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_inq_status (status)) ENGINE=InnoDB");
    $pdo->exec("CREATE TABLE IF NOT EXISTS activity_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        username VARCHAR(50) NULL,
        action VARCHAR(30) NOT NULL,
        description VARCHAR(255) NOT NULL,
        record_id INT NULL,
        ip_address VARCHAR(45) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_log_action (action), INDEX idx_log_created (created_at)) ENGINE=InnoDB");
}

function seed_users(PDO $pdo): void {
    $ins = $pdo->prepare('INSERT INTO users (username, password, full_name, role, email, phone) VALUES (?,?,?,?,?,?)');
    $ins->execute(['mreyes', password_hash('doctor123', PASSWORD_DEFAULT), 'Dr. Miguel Reyes', 'Doctor', 'miguel.reyes@schoolclinic.edu', '(123) 456-7890']);
    $ins->execute(['acruz',  password_hash('nurse123',  PASSWORD_DEFAULT), 'Nurse Ana Cruz',   'Nurse',  'ana.cruz@schoolclinic.edu',      '(123) 456-7891']);
}

function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;
    $opts = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];
    try {
        // Kumonekta sa MySQL server at gawin ang database kung wala pa.
        $server = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, $opts);
        $server->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4');
        $conn = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, $opts);
        $tables = (int)$conn->query("SELECT COUNT(*) FROM information_schema.tables
                                     WHERE table_schema = DATABASE()
                                     AND table_name IN ('users','students','medical_records','inquiries','activity_logs')")->fetchColumn();
        $ucols = (int)$conn->query("SELECT COUNT(*) FROM information_schema.columns
                                    WHERE table_schema = DATABASE() AND table_name = 'users'
                                    AND column_name IN ('email','phone','last_login')")->fetchColumn();
        if ($tables < 5 || $ucols < 3) install_schema($conn);
        // Kung walang kahit isang user, gagawin ang 2 demo account.
        if ((int)$conn->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0) seed_users($conn);
        // Ayusin ang email/phone/pangalan ng demo accounts galing sa lumang version.
        $conn->exec("UPDATE users SET email = 'miguel.reyes@schoolclinic.edu', phone = '(123) 456-7890' WHERE username = 'mreyes' AND email IS NULL");
        $conn->exec("UPDATE users SET email = 'ana.cruz@schoolclinic.edu', phone = '(123) 456-7891' WHERE username = 'acruz' AND email IS NULL");
        $pdo = $conn;
    } catch (PDOException $e) {
        http_response_code(500);
        if (defined('API_MODE')) {
            error_log('[clinic] database error: ' . $e->getMessage());
            header('Content-Type: application/json; charset=utf-8');
            exit(json_encode(['ok' => false, 'error' => 'Cannot connect to the database. Check that MySQL is running in XAMPP and that DB_USER / DB_PASS in config.php are correct.']));
        }
        exit('Database error: ' . htmlspecialchars($e->getMessage()) .
             '<br><br>Check that MySQL is running in XAMPP and that DB_USER / DB_PASS in config.php are correct.');
    }
    return $pdo;
}

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function redirect(string $to): void {
    // Ang $to ay isinusulat mula sa main folder ng system, hal. 'dashboard.php'
    header('Location: ' . (preg_match('#^(https?:)?//|^/#', $to) ? $to : BASE_URL . $to));
    exit;
}
// Server-side guard: ang mga page maliban sa index.php ay nangangailangan ng login.
function require_login(): void {
    if (empty($_SESSION['user'])) { redirect('index.php'); }
}
function is_doctor(): bool { return ($_SESSION['user']['role'] ?? '') === 'Doctor'; }
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}

// ACTIVITY LOG: isinusulat sa activity_logs table (login, logout, add/update/delete, approve, inquiry, ...)
function log_activity(PDO $pdo, string $action, string $description, ?int $recordId = null, ?string $username = null): void {
    $u = $_SESSION['user'] ?? null;
    $pdo->prepare('INSERT INTO activity_logs (user_id, username, action, description, record_id, ip_address) VALUES (?,?,?,?,?,?)')
        ->execute([$u ? (int)$u['id'] : null, $u['username'] ?? $username, $action, mb_substr($description, 0, 255), $recordId, $_SERVER['REMOTE_ADDR'] ?? null]);
}
