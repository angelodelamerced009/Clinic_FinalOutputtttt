-- School Clinic Management System - MySQL / MariaDB structure
-- phpMyAdmin: open http://localhost/phpmyadmin -> Import tab -> choose this file -> Go.
-- Safe to import more than once (CREATE ... IF NOT EXISTS). The PHP system also creates all of this
-- automatically the first time you open it, so this file is optional.
--
-- Tables:
--   users            login accounts (Doctor / Nurse)          <- LOGIN, PROFILE, CHANGE PASSWORD
--   students         one row per student                      <- STUDENT RECORDS
--   medical_records  medical exams of each student            <- MEDICAL RECORDS, RECORD STATUS, CLEARANCE, ANALYSIS
--   inquiries        messages from Contact admin / Forgot pw <- INQUIRIES
--   activity_logs    who did what and when                    <- ACTIVITY LOGS, DASHBOARD "Recent Activity"
-- (Dashboard statistics are COUNT queries on medical_records.)
-- The two demo accounts (mreyes / doctor123, acruz / nurse123) are created by PHP on the first page load.

CREATE DATABASE IF NOT EXISTS school_clinic_db CHARACTER SET utf8mb4;
USE school_clinic_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  role ENUM('Doctor','Nurse') NOT NULL,
  email VARCHAR(100) NULL,
  phone VARCHAR(30) NULL,
  last_login TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_no VARCHAR(20) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  year_level VARCHAR(20) NOT NULL,
  course VARCHAR(50) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_students_name (full_name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS medical_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  test_type VARCHAR(50) NOT NULL,
  exam_date DATE NOT NULL,
  status ENUM('pending','ongoing','approved') NOT NULL DEFAULT 'pending',
  remarks TEXT NULL,
  doctor_remarks TEXT NULL,
  height_cm DECIMAL(5,1) NULL,
  weight_kg DECIMAL(5,1) NULL,
  blood_pressure VARCHAR(10) NULL,
  heart_rate SMALLINT UNSIGNED NULL,
  vision VARCHAR(10) NULL,
  hearing VARCHAR(50) NULL,
  created_by INT NULL,
  updated_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_med_student (student_id), INDEX idx_med_status (status), INDEX idx_med_date (exam_date),
  CONSTRAINT fk_med_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE
  
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inquiries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  type ENUM('access','password','general') NOT NULL DEFAULT 'general',
  message TEXT NOT NULL,
  status ENUM('new','read','resolved') NOT NULL DEFAULT 'new',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_inq_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  username VARCHAR(50) NULL,
  action VARCHAR(30) NOT NULL,
  description VARCHAR(255) NOT NULL,
  record_id INT NULL,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_log_action (action), INDEX idx_log_created (created_at)
) ENGINE=InnoDB;

-- ONLY if you already have an OLD `users` table (from the first version of this project) and you are importing
-- this file instead of just opening the PHP system: run these 3 lines once. (The PHP system does this by itself.)
-- ALTER TABLE users ADD COLUMN email VARCHAR(100) NULL;
-- ALTER TABLE users ADD COLUMN phone VARCHAR(30) NULL;
-- ALTER TABLE users ADD COLUMN last_login TIMESTAMP NULL DEFAULT NULL;
