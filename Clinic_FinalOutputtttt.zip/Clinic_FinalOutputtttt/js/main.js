// School Clinic Management System - ALL JavaScript in ONE file (drop-in replacement for js/main.js).
// Each section below is one function/file from the split version: look for the "=====" lines.

// ===== core/constants.js =====
// School Clinic Management System - PHP + MySQL version.
// Data is saved in MySQL through the PHP files in api/ (see data/api-request.js). Nothing is stored in the browser except the "remember username" box.
const TESTS = ['Physical Exam', 'Blood Test', 'X-Ray', 'Immunization', 'Dental Check-up', 'Vision Screening'];
const YEARS = ['Year 1', 'Year 2', 'Year 3', 'Year 4'];
const COURSES = ['BSIT', 'BSCS', 'BSIS', 'BSA', 'BSAIS', 'BSMA', 'BSBA', 'BSREM', 'BSIA', 'BSLM', 'BSMedTech', 'BSN', 'BSCoE', 'BSElE', 'BSC', 'BSISM', 'BSHM', 'BSTM', 'BECEd', 'BELEMEd', 'BSEd', 'BTVTEd', 'ABCom', 'ABEng', 'BSP', 'BSM', 'ACT', 'ABA', 'CIT'];
const ST = ['pending', 'ongoing', 'approved'];
const API_BASE = 'api/'; // folder of the PHP files that talk to MySQL

// ===== core/icons.js =====
const ICON = {
  eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3.2"/></svg>',
  pen: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 17.3V21h3.7L18.8 8.9l-3.7-3.7L3 17.3zM21.6 6.1a1 1 0 000-1.4l-2.3-2.3a1 1 0 00-1.4 0l-1.8 1.8 3.7 3.7 1.8-1.8z"/></svg>',
  bin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
  user: '<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="24" fill="#000"/><circle cx="24" cy="18" r="7" fill="#fff"/><path d="M9 40c1-9 7-13 15-13s14 4 15 13a24 24 0 01-30 0z" fill="#fff"/></svg>'
};

// ===== core/state.js =====
let db, me = null, view = 'dashboard', editId = null, selId = null, viewId = null, role = 'doctor', msg = '', err = '', q = '', F = { year: '', course: '', test: '', status: '' }, csrf = '', inquiryType = null;

// ===== helpers/select-element.js =====
const $ = s => document.querySelector(s);

// ===== helpers/escape-html.js =====
const E = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ===== helpers/capitalize.js =====
const cap = s => s[0].toUpperCase() + s.slice(1);

// ===== helpers/date-string.js =====
const dstr = (off = 0) => { const d = new Date(); d.setDate(d.getDate() + off); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };

// ===== helpers/time-format.js =====
const tm = t => new Date(t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

// ===== helpers/is-doctor.js =====
const isDoc = () => me && me.role === 'doctor';

// ===== helpers/option-list.js =====
const opts = (a, v) => a.map(x => `<option${x === v ? ' selected' : ''}>${E(x)}</option>`).join('');

// ===== helpers/notice.js =====
const notice = () => { const h = (msg ? `<p class="flash">${E(msg)}</p>` : '') + (err ? `<p class="flash err">${E(err)}</p>` : ''); msg = ''; err = ''; return h; };

// ===== helpers/status-badge.js =====
const st = s => `<span class="st ${s}">${cap(s)}</span>`;

// ===== data/api-request.js =====
// MYSQL: one function for every call to the PHP files in api/. Always returns {ok, ...}; never throws.
async function api(path, data) {
  const opt = data === undefined
    ? { credentials: 'same-origin' }
    : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(data) };
  try {
    const r = await fetch(API_BASE + path, opt);
    let j = null; try { j = await r.json(); } catch (x) { }
    if (!j) return { ok: false, error: 'The server sent an unexpected reply. Check that Apache and MySQL are running.' };
    if (r.status === 401 && path !== 'login.php') me = null;
    return j;
  } catch (x) { return { ok: false, error: 'Cannot reach the server. Check that Apache and MySQL are running.' }; }
}

// ===== data/load-data.js =====
// MYSQL: loads the logged-in user, records, dashboard statistics and activity log from MySQL (replaces load()).
async function loadData() {
  const n = new Date();
  const j = await api('data.php?year=' + n.getFullYear() + '&month=' + (n.getMonth() + 1));
  db = { rows: [], stats: { total: 0, counts: {}, calendar: {} }, activity: [] };
  if (!j.ok) { me = null; err = j.error || ''; return; }
  me = j.user || null; csrf = j.csrf || '';
  if (me) { me.last = me.last ? new Date(me.last).toLocaleString() : 'First login'; db.rows = j.rows; db.stats = j.stats; db.activity = j.activity; }
}

// ===== views/draw.js =====
function draw() {
  $('#app').innerHTML = me ? shell() : loginView();
  if (me && view === 'status') wireBoard();
}

// ===== views/login-view.js =====
function loginView() {
  let saved = ''; try { saved = localStorage.getItem('clinic-user') || ''; } catch (e) { }
  return `<div class="login"><section class="lhero"><h1>SCHOOL CLINIC</h1><p class="ms">Management System</p><p class="tg">Faster, safer, more organized student health records</p></section>
<section class="lform"><div class="lnav"><span>Need Access? <a href="#" onclick="return A.inquiry('access')">Contact admin</a></span><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFwAAABaCAYAAAA1tjFFAABIh0lEQVR42rW9d3hcZ5n+/zltzvTRqPdiyZaL5CL3Etc4Tu8JEGqAQICEsvtlG/vbDexmFxbYpUPIskAglfTuxI4d9yo3uUhWsXqXRtNnTnl/f0iWewrLji/5ujQ6c+ac+33O05/7lRobmwDBh3uJy3xGQpIm/ioufH/yUxN/kC460+SREycQZ/9/j8uSJr/sksu45PvOvS1d5kAbSbr0i85+Vpx/9Hk3KJ1/Huniz553DxMvWZJAklD5c17iMoBL429L0jjwQrw3SOctw3vhKi743JXAP/9gMb724qILEOfhdU4oBNKVV/QC6RFXEJTLX9qVz/vnAX45CRXifYH5oKeaeF4uIzmXLo0sSZOflM6dRLzHunDlQ/7vX+qf+8V/ocsdlzPbHl8s6TIPviQRj6cIhWLE4mni8SSWJXDoGh6Xjq4r+DxOfD7XFa/Mtm1kWb6c9rqiVpLOO1BcRvrfS7TeS/DUvwR0f4ZkCwDLssalVFEASCVNBodDNDf3cvxkP8cbzjA4ECIaTWIYFpZlY1kSwpaRJFAVFVVVUVQbt1uiYkoBNTWlVE/Lp6w8h8ygF13XUBQZIcCybGRZQjqntKUrXZx0/uKLPx+jyadyYpGkxsaTf9FHZtLwiUvu55z2sQXCtkmlDMbCCQ4faaW1pZ/9B9o4crSNRNzC6Qxg2TqmJSHscdXhcKgYpolpCWQksGWEEEiyjU0KTVOANIgk/oCT8ilZLJxfyZw55VRPKyIjw42ua2dBv9gBkC53H9IVVNmfBbgkfXjAJd7TWlxklKRLnlghBP39YU4cb2f33hZONHRxunmUZBokFGTZAUIlbYAk2SDExLnsycfbFhLYYhxsQJZlJEVGlieMlWQhhA2SQNgpnE7B9OoCKqZks3zFVGpmFpOfnzEh+eLiW5H+TwFvajr1vie8WKeKK0q1uAjw8bckScK2bTo6Bnlny1H27ztDY+MA4YhFKiUhhANNc2AYSTKDLrJzPYwMhUgkkyBUEgkQtoJlWyCU8R8kJGlc0jVdQnXa2GacnBwPXp+LttY+DMuJoijYpoVhGsiKRE6Og/IyD0uWVLJmdQ0VFfkoinyxapSky9iT/w3wk6B/EAmX3sNgXqy/hZh0zrBtgSwpjI3FePyJbbz66iFCIZt02iYnz0l5iQdFU4hGZA7X91NR4eeBB65mzrwyUskUg4NjdHWF+cnPttPVmeasgQV53LWUBLIElVUe/u4f1uD1aWRm+nG5dPbsPs7DD7+MJHkpK83A4bRRZIW2MyMMD6dxOJz4AxI331TDnXcsIT8/iBACZcKeTNyX9JcGXP2wYJ8V37OG5TIXIcSEGkjEDbbtaODXj7zFqVNjOHQnOVkyX/nKatasrqGwIIBl2by58ThNjU/z5a/cyrp1sybO6UFTFZ58ag+9vSEs3KiyPe51WOcCKEtYtLR1c6qxi499bDm6riIE3HjTYmzb5mc/e4dP37uSq9fNAOBUUx/PPrOfF188RmhU57e/3c2O7ce59941rFkzB0mSkGX5rLoS4gItKv2vgVcefPCBDw34FVSKAB4SQmAYFvWHWvnRj17luecbGOzXcDh9BAI299+/jLvvXIbP6ySVMnn2Tzv42c/fYu3aWmpqivD7XMRiaU6c6uZHP3mDd7a2ICs+LMNCUcC+IOYad+BkReVgfTMnTrSTlxdA1zVSKZNozKS3N8HGt+rxelVmzCgmM+ihrq6U4ZFRjh3twu3OZSRks3PXSRqOtZKbFySY4UZVlbOexUOM/3z7fxln/C8izfPD9HNgI4RgaDjCKy/v44UX6+npiaMpHvz+AGORQcrKPEyfXkw0lsRM2xw/2c6zLxwgHJbZubOXQ/WdzJxZTCye5nTrKF1dY8iyD8uW0B2OcTdS2MiKhCQEQsgT1+HCNJ3s3DVET+9blJV4UGSVhhP9jIVMZEXn8cfrqajIp7goCxAsXlxB/aFe+notwIFl6uzcMUB310tcs2E6d921nMxM3/kqU1zpgf9QmDc2nnzfs1y8spZtT1h36QJ93dDQzqOPvsGhw53kZmcybVoJDcdHGOhLIaQYtTUBykp95OVnUlJYwBNP7aWpOUw6reJQNHRdJxqLoSoSTl0lljIwLQmEhGWZSIqGsG2EbU5cszIRXdqoDgVV0UG2sa04QoAi+zCtNIoigUhQVqrzsXsW0tHZw8DgKKOjNvX1A0jCw4yZuZQUejhY30IqleKqVWV8+Us3UVyYNeF6Smej3yu45u+vZgSgTiRAPrSvfRZseyJKPHy4je/8yx8YHh7h/i/dzPo1dYTHUvzDt54ivyDO33/rbsrLs4lFY3jdbtrPDHHqxPC4rlYkZAGRaAxZkxEYpFNjuDULxSMw7TSKQ6GkMJuivCz8Hh0rbXCma5iOnmGSaQtFcWIaKkZaQZYUQMEyDVSHgmWmUYREf1+cYIaPpUvXEIslcLldtLb084tfbCE7y8E//fNNjI7GefKpTbz0wjaamjp4+F8+T2VlAZItkGXpbKJEOpebkSYWXVziRp4vqELYExJ+6sQHjhTPNxpiwjimUinq6zv514f/yPTqIr7ylZupKMsjnTb5xS9eZs++0/znD+6jqCRz8kJ6Oof44pd+yUCfG4QTIRKoaoKMLCdFBW6mVuUxvSSHWbNLyMv3I6IJ5FgUzRYo2BPqxEQoEoaqYLg8xCWNwd4QHV1jHDvVzenGXlq6E0RTCrahIpmg6zZz5wf4+7+/jdLSHGzbRkLinS2H+d73X+Guu5fzxc+tw7JsTpzs4DvffoLhkRh/8zd3sOqq2ei6ds4tli7018G+OAg550YLMfl39c8xBGfBNgyLN9/cx+9+ewDd4eSOO5ZRXpoHSESjcTq7erhm/VwKi7LG3TkJ2loH+NVPXqG/38KUTFxqlGkVQZYvn0lJWZCaokyyZRuztxNz/y5IGJiDwySH+5BsC1mWsS0LIUw0XSBpKgQyUDIyyHN6KC8u4rrbptOTnM7+rjDtzSGOHu3nVOMgKVvm+IkRnn1mD5+5dw0ZQS8Cwfy6KcyZV8mWLcf5wmfXAlBbU8Ff/b87+dY/Pscjj2xDQmXN6lpUVUaSZZDO1+niw+RSPrShFLZtY5oWb79dz3//9266u2KsXz+F2poKJAlkWaKjc4B4PIKEQcOxVioq8tn67jGee76e4ycGkGWJ9UvyuXrDbGbNKsM30kVozwG873QjjY0gORKomaVYeUVItTNxeGpQXC7QJrSgAMkysBIJrLExnJ0daM0nMbZvRwq4KSrKRc4uYf2qeURuncOBo51sfusoew9389wLDbR3hFi7ZirzF1TR1zdMeVkux4620nS6i6lVxdiWzcK6acyaWcGOHR381482kjbT3Hjdoovtl/SeMctkKnsikGr6cKG9mFAnbNt+nH/9l5cYHYljWTYbrq3in//pE8iSzODgMP/8nd/T1DiEYWgosoYky6TTColUBLdzgF/8/G+YWzsF68Rphh99CldfC1EBYtp0AmtX4V++CEl3ICbcs/d92QI5ncKMxRk7sJehjW+jN3XgFTZWZRV5X/8yZlkpm17bzc9/vonTXTEUxSIrM59INIzXI+H2QnlZgL/6+p1UTilGUVTu//KP2X+gFzMtcDoV/vO/PsXSpdMvkmQxmSOWLlAj4iLApQ8F+ORzc/jIaf7mb3/BzBkzuOWmq/jJT99g4aIyqqcFME2LpsYzVE2txO/L5Qf/9S7DQwlUWSI/x+a6ayv5xEevQmtrIbpzC5FTTeiBYrIWzsOxYD7qlHJQlcmkkhBiMn1rGAbDI6PouoNgRgbpdJp0MoXudKLpjvPyHwJhWZgnmkgfqGfsyHGMUAR3VQUZ61cw4Mvhmef38ubmRgZG3GhODb8/za8f+Qzvbj/A2OggxUUFIEFPd4KOzh7Wrl3GS6/soa93gP/3zVtZumT2ZEpg4lqlSwG3EYILAH/fwOdisI8da+GHP3yM1Wvm84Uv3EA4EuL5F7eRk+NhydLpLKibwfr1S6mqLOGNjYc4eqwb2Yxx1bIiPvfZpVxbnUXkpZcxt+3En5mF5/rrybj9FvQF85Ayg6BICNtCAAPd/TSdaEZ36ri9Hjq7unn66edQFYWS4mK2bd3OUGsX3W09FE4pJjoWJhFL4HS5kGQFJS8HrXYmjtk1aLm5KF1dJHe8iSs8St3aZVTOq2BwcJDugSGEJfC7Ve797Abq6mrIyc7AsgR79p2gt2+Uu+9axdVXz2VoeIidOw9SPb2czKB/YpElJoOjiys/0vlPwgcH/CGA/v5R/uM//siMmaV89nO3kpHh5fjxFg7sP8mXv3IrixbORNd1FEVi/75m/ud32zAScT5zTx2f+9xqikfbsZ56Bk9oDO3O23DdcB2uadNQfF4EkEqm2L/9ADt37WX6zGm8+tKbhEMxsjIzCWZn0NPTx7H6kyxesJB9u+oZHRllyeplnD7VgZmy6GxrJ55IMTI4jMfrHs8kaipawI9eUYo8awbC6URs30OivoH8qmIW37CYVCpGa/MI3R3D1NWVkJsXxOV2UVpaiMOhsW9fM0uWzKS8Io+a2krOnOnnyJFW5tdVo2nqRLoXJPj2FTJOkzpc/qDSbRgmzzz9NoZh88X778bndU26QykjzOJF43pNVWUS8RRPPLkLK25w3z2L+Mz915P/7mukfv4TUgX5OB/6Fr7VK1ECAYQs097exTtbttPR0cnxEy3k5uXR1NTEkmWLGY0m6OzpmfRlTctEdzrZtm8HM2bPIDMvG09WgCOHGunrGyOvII+W0x2cOt7Cf/7rr0hE4qQTKQQgZwbxXH8L6jf+GtPjIuPxJymu38ZX71vNHTdPp6s/wh9+v5lYJIYkQSqZpqI8H4dbYFomsqyQEfBy/fUrON08xN59LeepD4lxU/7eOZL3k/DJkP3w4Tb+5/fvsGLFLFYsr8WyLBRFof1MH0JI1MyqJB5PcuRIBz/4j1c4cbKDT398ER+5ZQHS479lZOcWnBuuI/jJT6FkZZ315dn+7i62vrODcCSC0+UEVedQ/Ul8AQeZWbm43G6OHT/JwkVziETCZOUEmVtXS3l5JU8//QZDgyHOdHSRX5TN0ZNNZGT6GQ1FqT/UjGkJMrN8NNQfQ3M5SRsGbp8HLTcb/+KFjIZCJLdswRqLsureW0ibUTa/20xn1zDBgBe3RyeeSGJbgikVRWRlZwASHq+H0829/OY3r7Ny1WyyMv3nl7IfAvHtS6GUQXp/lfKQEIJ02uTHP36Nw4e6Wbe2htrZFQghGBkZ4/e/fwFhSSCZvPjyfh77w37CIzHu+9Rybl5aiv7SC1gdPSgfuwfvhutRfH4SsQQHDx5DmIITx1tYsWoJxcUl1B88hWEIdKeLgvx8kqkUqaTJ7Lk1+P0e3B4vhYUFIEl4fV6mV1egaipLlsymvLKYpqZWhCkxNhZnXt1MVFWi4UQrvoCXXbsO0nTyNIGAj8ysIDid6PPmYsoOzD0Hiba3s+YT1yN0lbfePs7mLY1EolEgzM6dh4hGokydVoHT6UDYgmPHzlBfP8DQUIS6+RW43fr5BvTblxrAcbXyXn64mCi+svWdQ+zb14quezlytIU771pJa2snZ850snr1IgoKcsnPz2bj262YCZsv3LeI29ZMI/74H4l2d6F98cv4Z8+c7Nd45umXsQ1wauPGbdeuw5RVFCNpGrVzp5IR8KFpCoWFuSiKQjSe4hd/3EHvaByHOu6HI+lIism0YiczZk7B43Zw7713kE5aRKIxiorz+OXPjzE4GCEYzGTh4nkU5Gfxwgsb+VJpMR6PG8Wh4b/xOuJ+D0OPPcbor0a5+3P3gWnzu6cP03y6l698+XNkZefS2tzBnl31VFSW4PMH6OgcwevzsXP3CTa9XcTdd688q8cnVIuQLqdXrijhQoiHJEmiu3uA//fNH3L9DUsIBr34fC5amk8xNDzM+vUrmDWziuLiPFqaennjud3cftM87rl3LfYffofR0gqf/Ay+ebMnI14JCAQyePXV3XT1DnDrbWuxLJv2zh6WLK7Fwkl3f5gF86ZO5KYlGlsH+MmTnZzqUWgbELR0p2kdtGnuSTEyOsLS2cVk+Jw4HDqhsRSHj3eRnRUgvyCbdMpkaHCEDdcup39olKHBEebOncmpE014fV6cbheO0mLcRSXEX3oJPTLI3LtvpKtvgKPHWlizspYZNZXMmFlFxZQSXn9jK/v3nyQUkrnttvn4vCZ79hxj/oJqfD7X2XwLXGBAeV+3UJwtiz3x5EZsS/C3f/txDh48xb597YTDQ3z9ax/H53WPn0qWefG57eiKyr2fWY3ruRcJ7d+J6+MfI+Oqqybt9b69+9m35yB182sJZvno6BykbyhC9fRyplXP4PnNHfz2pWbe2NGOkU4wvTIXh6aydV87W46EEaqOJavYsoJhWBhCQldlFkzPpaQgg86eED/73SGefquLPcd6CQa8zJ9biiVMdu09yu49J8jJLmDru/Xs2LaLxYvnIBCoTg2lpBA9NwvlwF4wJKrXL+H1d/egaQ7q6qqRZQlFUaisLGXjxkMcPnSGadWZfP6zN3D46AmSiQSzZlWON2JJEhLSQxeCPpG7fy8F3tR0ht27D/KNb3wSXdfIzvYxMpxk7bqr8Pk8CDFewG1t7mb3rgNcc80M3I0NjGzchLxiDa5lKxBI9Pb1cepkE2UVUzAsia1bDiCEjNvjIpgRYOeBfv72B9t4eccwo2YQZ7CKJ17v4tdPHWJ/Qz/7GoaxBaiyTMpIkUyn0R0aiupgIGSz+8gwBxr6+a//2cvuE3EkdwHtQ05+9mQj//3cKWRXHvPmzmJO7TSGhgfp6x9m2sxZZGZn8vgfXqK7qxdJltBXriQ+u46xnTvJGOjmq5+/id17jtJ0sn0yTHc6dUpLC0gaKaZUluDzubjpxuUcO36KwaHR8/3yy7opygMPfOVylRssy+K55zZRUlrIhg1LkKRxgPbtb+H66+dSVpqLZdkcPdzGd//jaWpmFHPb3HLsp54kOrWS/M/fi+RyYaRNBvqHaTjSSGg0wuy503nqmY1ouovVq+bzzs5+Xt8XYcT0YMgqScPCshWE7KStJ8nehgHO9Juk0tp4dk/RUAHFNpBVF5Kk0tY1wq6j/TR3QVp1kTYsZFUnLekMhiyOHe/Gq6X55D1rqK2ppKurnxkzqmhoOEnbmR4G+oYpLSvE43Oj5OVh9XQzVH+QebfdQEv3IDu3n6Syshh/wI2qyrS2djIwOMTHP7YWj1vH5/ew/8BJNFVl2tTS873AyWBIQka6UsXHtm26uoZoaOjm69+4e7IrIjPoZeWqalRV5Sc/fZbRUZODu9sZGD7Df/37pxh94gkybJuC++9D9vvo6ezh1Zc2kRHIoqO3H384zqatO1m5cgHXblhFJJYilLYJmyoJ28aWwJYl0nZ63A+2NYbHTCxDICsyqqygSgoyBk5ZEE6YOF0KYykYNjRseTwvbcuCmJFAVVRMWyFpSuj+AJqmous6Ab+LN97YzLXXrqG2tpLuzt6J4oKMlleAevXVuH/+Y+yXn+NjH/sI//qPj/OPf/8Yc+aXozgEfq+LWTML8Hh0hBBkBHzUzKri8Sff5vrrlmNZFqoiXzZYly/ObNkT1ZxTp3ro6U0T8Puw7fFcrubQaG7t5uF//w19fVFee+0Ew6E4//Zvn8XX3oF8/DTi+hvQMjOwLYtTx5upnFbBzXdezYpV87Elgwcf/DQ33bQOVVUI+FzMmBpE1WyEDNZEGl9IAiEJklYKQ9iouhOHriGwkMQAkj2IojkAC9NWMCQvKRsswJ6wzEKRMRQQso3XbbJyUTlCgK47uO22tdzzsevZtesQLU0DCMvB6y9v48SxJlAUvDW1ZF99DbEtb+HramLdhrn0dEd57k+HsYXKocPthEJJJKTJ1LdT93OmLcn+g20oinJBf/FEVgiBuESHC9sWJBJpduw6ycBAijNn+pAkiXTaZM+eBhLxMb764B1suHoBGV6N+XPyWL5yDsNvvIOvohzXssWIiejLtCGRsIlEoySTBqYJiaTFma4hwtEklg0lRZkEM7zjnVTnN60iIUsyiqwghI1tmWiySUmegzk1xYwMjeJyO5CEDcKeSE+LCxqMJRsUBEX52TidTmKJFIPDUc50jjIWS7NyZR3ReIiaOZVUTi3l+adfZ6BvCEmWsZasIBLMxLVrC7Mrs6kqzUYFrt0wnxtvXExf3yCHD59CVRUM02JszMBI+3nllQNYln1+Zf+8/lL7UpUiSRCJpmhuGSKRsHj00beoqMjnYP0xmls6ePDLt7BgwQwO7GkiwyVYt6EGubGZcHsr7o/ciZIRQAjYteMADqfOwOAAb721k1giTllFJY/8cQ8RyYXPKVGQl8uZ3iSx1Hhx4vyiyXjGUyDJ47bFNONYqRFkO4JTL0TWJGSGUSUVw9ZAVjhbFTjrDSgCUtEkvf0qv32hAZdi0jsUp6cvxvyaIF/+xHI2bd5J3fxZmIbJm69vIRFPIYTAUVhAzu13YfzpcTJql7B+3QyaOrsAkzVr5+HxKGzbfpBkMkFxSTG7dp8mEU+xf18jrW29VFUWXLbSeUHFx7ZtFEXh5MkuhoejVFfncurUIMcbemhoaOKGG9YwbWoZkiSRSiYJZjqoqZnC6K9+jTfLj147A0lV2b11Dzu37+Pjn7kTf8BHOJJganUZr2w6zaFWHTUji6HwIFpzDMtWsRBYZ/PHZ6tXwkZVVGQkhJHC6xCUFjtYMlfF5Ypx9PAw5QUBWs4kUEUhtqRi22BNdGRJAmzDxOXyM5IweXVvGJcqY0kg2ZmM7htl3ow2amtreOx3L2OkTYrLStGdGmOjYwSCAdyLl9P90suop08za9EaNJeBJMl43E6uumo+ZeWF/Mf3H+Oq5cvp7xtmVm0Rfb2dNDV2UTkl/7LVH/li3xuguaWNObPzuf+Lq1Edgl/88lVqZtVQPa0MWZawLIvO7h5qagrJjoWwG44RmD0HZ2kpZtrgyP6T3HDTNZSUFKKoCg0nThKJwzOvn8FQAgyEk9iyj6QFadvAsEwQAqciodo2Im3gUmS8ioxTmARUG3f8DB9br3H9vBB3LAjx4G1x7r2mmLJAiGwveCUbpwIuh4JiWWjCxlIlErZJAomk4mBMKMRNgWGniZsevvvofq7dsJSly+eSlZMFOLj/K9/lwL6jYNuQmY265hrU4w3UBp0sm1fImdYuQKAoUDmliNWrlvPYH3ajO+Chf7qeSKSHk6e6SaXty6a31YtrcaZpsXv3Ia69Zhl186Ywa0Ye9Yc7ycwMTHYkpVJpdu+rZ+3qRYTrT2DIKgUrlo0/IZrK9LnTePvt3RimzZ79DcybO5PHXzlFQgliCBsLgW1fOCWgSTaqpCGrMqpkogmDHIfJwrl+5tfmU1s1h7zMDgq9p5DSx5jz0Wqaex3M/P8+xcm2ONv2t9PQlqa1P4nm8GEgwDIxxyuwWDbIQqDaNpJDRUgasZiPZ149xIJZ2WRmeehNpLnx+rWUlBYSiyXw+n0EZs8l/vpbGB1nWHrVAo7sP8769UtwTeROCgszGRkZYN26xRQVZfK5+27lwL5mxsai6Dk+JPnKEg5AR0cvbe29VE8vxed38+CDt5KRodPW1j+e4ROC7duOEQ0nmVmUh6uxC6u6GrOkePLxWbBkDgsX1tDS2sPcudUI2cWOg83Iuoolgz0xkjFp4myBMtl/YCObYWaXK3zz3tnc/9GZLJhhYMb2YY3swBo9jYh1oCZO4LN3ExraSkVhmPs/OpO//+xsrq7zoFmj6MpE/+HkvwkJkzXiKYO0sHBn+Hh7dwey5sShq7zyxhY02aKl6QzxWBJh2+h5+ThLKhk7eIwl82ZyqqWLNzfuxjDM8erX4RPMmZPPnXeuwOt1sXxZLcmkweDAKLIsn5v5mfi5xGg2NHTg9QTIy8vGsmyqphbwhS9cS1fnKMeOtfLGa3t4663D3LihjjKXDsMDKB+5FkXX6evsZd/eo6y95iqWr5xPKpVG0zTCkRhTS10c6QghZD+SGJ92mGitRZZlLGGDZaDYMVbODfAPn1uCLEZIx4+jSO1UFITJFL1oSpJ4RIGEiVc/Q1G2wlBcY3iolWz/VL72yTqy/Ed4adcIquLFENKkKRVI2ICsaMiYREZ7uOXaaRTk+Ok6Y/HgVz/KnFlTcblduD0uJEnC8riITa1gcNM7VPmcZGRn8sgjb9LU1MN9991AU2Mz1127lLKyPCRJIjvLj2Ul6ekZZNasUuTz/XFxGQnv6wvj9wXRNA1JHgfj2msWYFkmD//bU3R0DZKIpqkqLyTV1YkiRwgumgdAW0cPm7Yc4Hf//QJP/vE16uuPYxgGmUE/P/iHW/nEhgqcxDn7lMmShGSL8QZ9oeCQbZbNyuD/u28ZujyCKp1AkZvx6AmwjiAlDyEziN/txmkK0sk+dDFCri9Jtj+GrjZipRv53J21LJ2pIkkWqjxxkxM3K8kybpcHxRjhG/fM5WufWUF2lp8N1yznquV1KKrK8eMtbHlrJ6ZlITscaNMqyXVo+Bqbqaubgd/lpa2tj6888CNqamYxv64aZUKaVVVBCOgdGMaeuLfztbh8sVLvaB+krz9Eb9/QZMDT2zvC1q0NTKko5OGHP09RsYfMgJOxtjNEHQqS7gAgNzuTL953Ozfeuopglp9oNIZljZ/D63Iwd3ohGX43ijbenibsNLoi8CoOnJZMjpriE9dUIRnDJEL1mMnjTKnIJMNjkClHcKQNGI3gMBMocpwsV4pMJUyOz6a4NBdLs0imTmMb/fz1p1dS7Y+jp2I4bAvNtnHYMpqsko6FqJ2Sz/pl1ZMdUSMjYX7w/d/wzBPvcOhAE/19w0THoghh48jLIZjpJ9XRydKlNcyemcXnP3cdoPLGG3uIxuKTfnd/f4i+AYOx0TRpwzpXXpMQSBcFPrZt09k9QDwGW7YcJR5PkUqmeeZPm3C54Ybr5+PzuSgocJJT4Id4CiOvAFvVSCZSnG5uZWh4hJKyAnRVorQon8H+EV56cz9Pvryft7c2YozG0U0TXVXQNAeKsHGKJD4R5uq5QWYUukgPN+N3xAlk5ZGImcS6unGH4zjimSgRJ8SiaMRguA9HdIDkYD9mXFCRW0CGx2Rs9DhuPc0XbptJkdsgV1dwp+Pk6DZuI4VuG/R3jfK7P+7ntTcbeHfLYYRlU1ZaiqKo9A9HOHK8iaGBEWRZQs8KonlcDDU3khl0k5OjM3NGOZ/9zLU4dY3N7xwgnTYJh2M8+eQ2omGbwcEYiUR6skXr7M8FOtwwDCw7xprVs9m06TA+j4fS8gzqDx/nO/98PxUVBaiqSkaGRsCtIxIJRGERkqoSGQnR3dPP1VdfhaIoOB063ac6SLR10XqoHcPWcSUVlkl+jjsz6JZ9OE2DotQwRXKYImeKtVIhYkszOdIIaaWLjPm1yLkFOIK19DQ249SLMJUUKklkRcY2fKTsPOKOIKOd/Uzz2OTbcdxOhb4zh1g4YyE3+ffR29w1Xg5IGMi2E6FJONM26ruttO2wUbQE2Z+7lltvX8OenceIRGOsW7WezOzguJpwOJADHpKtbXiEzZSKItxeF6vXzCU3N4Mnn97M3r0neWfrSbZsPUnd/AoSyTippDHhSJyLfi8AvK8/hNdj8Hd/dzPf/Jv/4U/P1rNm7TS++sA9VFeXTqoY2QFEoxAeQpo9FYBAwE9OZh6vvbKN2XOq2PnuHm5YsoDc9lZubzkAyQQuj4cGNYPf5yxAsTVmW0Osix9hjjxEfiICfxjAIVuYis2YaRCdfoSRa64nvfQqxtw3ouo5WMIB2KRTaTQhMRYzkRKgHTqKXL8bVZh41s4lp9pmrGkb9/TU4432YZoGAdWPOZYiLSfRnRZ+3cFoxCTmz2akpZ32rAA/+uHjrL96BQ31jWCZrFi3YLzr1efGaYUR8Rhetz6e+VNlZtWUc3NiCdu2N/LW5tNUzyjhr75+NY8/9Q6ptHlJelY9P3GViKeYNasGj8fFnXcs48c/eZW+3l5WLL9tsr3LNC2cDg/OeBIrlsDStPFFkGWmTC3BsixOH29levUUKquKsS0DTyqGkzS6rJElpclNx7k62cJqpZtZViuusRBOySDpcBLTnNiJJMUuJwNNYYYTBzgeDnKqOh8z5sKRErh1lTQSLlkjkUoxLTrCjI5ustssAg6F/jcP4sXDgJSHnQGpkIXLTJGR6B/vS7RN7JhFLOpgyJlFyDAwwhFyi/P4xGduIjSaoLjIx8w5VeNQ6TrpjCDRgT488RhupwcjlUbTHQghKC8v5veP7SAnaPG1BzbgdLlwedwXD45f6oen0mlyc7NQFJlVq2bzta/dgMtlk0ymsSwLIQSnG9uJDqdwyuMhtzQxExMai7B7Vz1z5s/go5++laHBEbpOtqAk4ui6iu5WSSfHEKZAjiepM7uYGWklP5UgYGtYKRcD+Xl471yNVRYkbXnJlnyU9fSTdfwkDYcbeffICd491cxAKEqu7CBLUinWNIKREBm97WSrJt6Eja83jtXZi692BpGbb+FP2bPZ5qjCAARRVDWN2ynoUQSPeWbyqLeWY64CentHCEfCrLtmHvFUlNde2TyZYEoLHbfDj4ZgYHCM3t5BLGu8I8yyTKqqMnn44U8xd045brcDn0+fNMhXbOa0LQvTHH8MNE1l1co5aIpEZ0cfVVNLiMdTPPvCdgZHEqiqBIqNoo6fIhaLI7Dw+d24PON+bM/J02QPjyAJEwUTBRuXpqNLCgFzBHc6hp02USQVTdaIZnkRdWVED+3C3WjhshIUOA0WKBYbHRp9iQS2pjKzoIBb59SgIpAQuN0q8isvIZkh7LQPn+JAVp04snKIZXjYlzlAYrQbOdGCKhvYponiUEk63RzIKKPFkYEV0Ug3dpNXkMXUqSVYRopXX3x70oezJQemcKJYgqaOfvqjJnd/NBdNU7Atm5tuXMbUqqLJHhUJ+7KFnwsk3BLQPzA6+bvDobFo0SwsS6K5uYd//96zvPBiEyYeZFnC5dJQJnpfsrODuFwKW97cyqvPvsFIaIiZC2tx+70IAWnDQFM1sAW6LON1OpFsG9WhIck2mm6SNg3SBigenaQ1Qlq2iBspXIrE1KoyTMtAyDaaLOFyONAcOrIsIVIxFNtCcoKaoYITzGSSdDJBNG2TsG0sM05qLASmgSJJGEmLVCJJItJJhivCjKoga9fUMtAfZnBglMMHT7DhutXngLIFQriQNSfRsMKjj+7gN49uIRJJYFo2ebmZkxNwyVSKRNLgcgPiF0i4z+OioaGRRCKNrqvjxdCJ/Mk/fOtxTp4KI0te+kYSnA2araQBgO7QmDtvFjs2H6BrsItFi2bgyQigZ3ix0zbICoYhQJUwsBgNJZCEhoSFkAS2ZOHNzGY4YhLNz0ZeGsW2BfG0m3SBTpZLgXgCW/KgSPJk47uVjGAQI1zoJZCnkxxLY8sOwm6Ip1PYqoFtDuPNAE/KizkwioaKouv4/R6+cE8dlSvnU1qaTf3B0yxfVktmlp/1160kmOmfKBJYqOEEpiEhZI1USieeDvCrR3Zy5EgLn//COvLzsibD+Eg4xtho9LK1TfX8xJVD0xgYNHjplb3cefsywCaZSPOzn79Fa5uFpuagaSoDA6cxJRlbQCoaH3cpTZOxUJic4ixyqsrQhI0pQyyVJF9SQRYgyUikqJjhJrPdhdQjYaYMFFVFlT2oGQVE3B6cqxYRuHE2OYV5hMMGWu40RsmguKGNqKmjycq5pJeukTl/Ksms2ygsDhLrHSY0GmUsqhPILqAgJ5/P3b2IsadfwepXcOouzFQSW7ZwqBJrP7oWWR9PRE2pLMRMpTHS1kSX1bncvGTaSB43ittFNBJDljQ87jyOHRrhxRf3UlGRj8s13sG7e+8popEEmqZeUki+4J28/CAyOo89thOnw8GaNbXs23+a7Tta0Z35WOb4HI7f52JM1pC8Xqzw2HiJyelk+VXLxtuK4wmEYaCFw6Qnxq9lyQJFwe1MUnf7MoL7fdjPDyBbIJHGMmxUzYmSm4ejwEuvGCLsEwhPgECWnwrVS16Gh1TIRkyoMcs2UUUEkSkzlA4iZWuELYmUP5PEYICigmJkWWbh8jkk46NoJ/djWgayJFBsQToyhn5evjory0c8Gr+UsMY0MEb7cWR6kF1OQqEERioFio5lOzh2rJ/TzT1UlOfz5ptH+dNTB5k5K38izBfnVfIvAtzl0nG7vRw9NsbD//Ya+/a1Mru2Astykk6lJ6yygiJ5GbTAk+HF29uOZI2DeTa8dXjcWIkUiFEw4yAZaNikjTiqpKM7FRRVwVScJCQDUyQIGSmiGLj8OSTSYfQMD+lkEl1VaDp6iOLqSgIijVfVkeTx+qCRiBELNdHX1UVGbpCxcJy0lcYwNDJzqrANg6GODrIqKlAUEOkkihgfPRRWGkXoE5PNEzbMslBVBYdTv7CoHg4jD/eg5WcRMSXOtI+iyDomBppDJ5kUNDUN8cgv36a11WY0JLN4ie8yEn52hnq87IokSUydWoHbHSBt+Nmxo49dOztQFQXNoSLLKgiFlCETCqVxBXPw9PYjx2LnqhsTWcDU0CB2MjUxUXaOJUdgIdkmti7oIUyzx6S5yMfAsjqShfkgZJJRNxlqEHvMIEfXmV6YgUOx8BgGQUWdTHhhpHGZKcqLApTk6mgpCzntRpWLcGWWEB0eoLetjVQ8jiIr2JZ8bhrqQq6kcbWYSBIZHL0EpFRvH2IsRk7VDEKhKGNRg0TSRJJtBHEkWePNN49y4kSEaExCVWwK8gO4XfoljSnqhRNYgqqKbBKJBlQtk7FwjPrDjcyclUkolGJg0ERzuLBsicbmAWZXlGNv3ok1OAR+/wXVf0dmENk0sC9ifxKyjC3LRDJ9jK2ci1GYiZTrJOXKIKx7SfaPkT7eSvCtJjLScaLmbtIFbgK3rSczMUJIc8AE/cZYTzfpM6fIiufRu3UTcmiEQn8+UW+I0akqw7pKKpUeN66WjWSrk1No8nkMD5NemdOJFLyUwCre30cknaRkSgnvbj2KsBU0WQZzjLvuWcDsOUUcPNBCW+sYku1Ad+oEg74JOpH3HKqSmDI1C9OKIss+nLrFZz69nDVrZtLeMcyjv36Xk6dGcTjcnG7uQ140F2/Qz/C+PWRUTrngIu1EEnmibUGaIMGybBvLNrEVhWTASaxuGvEp+eBKIVQFMywzNjBM6mAzyaM7yNQkEoZNaloB6QVhgtEwwYwgTmV8skB09yCPxkiao8RfaSE7FiMutdKV205og4tuj5f8nByGO7rIVMc9ogsmWi9i9kknEkQHR3B4SsYXxraR0mmUrnbCHplkYR67927EAGTFIj/fyb33riIY9DC7toz6+m5aWxL4AyolJdkoinz5mubZQVdJgupp+QSDKhZJSkqD3HzzAsrLc1m+rJpp1TnIkoIkFM50DNOdsInnBmh/+3XsdHryuZEVBcXrxTZMFMU5DrquITvcyEoASUjYwsb2uUn6HCQcaSRHCqQUyZE+fKEQ5YYbOSZwKQHMVCat3TKOuEa2KZM5McOU6OgiElOJmz4kw4HTDOBW80h5gzSPjGE7nPT0DdN5phPDSGOpAqFpEyAoWKaEOA8QSZIIlhScmxUSApIJMoYH8FWWExEqof44QlLGDbesYlkCRZExLRtFkZCUNF6vRm6u7zKNQOLSik8w6GdOTSU7dvUwNBSiu2cEv9/F8HCEoaE4ttCwgJaeFEf6UijFReQd3I166iR27exzlRzbInr8JK6ESdKUcTpl7LQLW87BssAdTuCVYSwJjoAbOSXR39PFlKSNY2iQmCwTLSgmPm0q8uJl5K25gVr/FEbTaQoyc8Y9ozl1ZGVnI+turMYBwgcOICWcGO48civKyJ1RTW97Jy6HTHJghITDhe4GEbKx0hqaK3NS1xmRKNHuPrKmV51H/aBgDA8ROn2KnHs+w2u7Ghke0lAlCYdTIjSa4uF/fYkFi0rYu6eJ9s4EoOD36wSD3vPHCydBPx9wSQghHA6NhQvL2bG7h+Fhk+9853lqasro74tw5Gg/hjFeg5SEQlvjEGs2LMR8+VWie/bgrp6OcDgmnh0Z2e8m7QJJCSKiEWwphWknEaqK2p8Yn5EvgUQ4zfCYQUFmGXmjwwzjZWT9ckZKc8i99mrUnBwkSaJs/nxKJ1iAJFmmcOHCSckMPPhl+l5+g2BLO0P93aSiMUzLomL61HFim2iCMZ+X9OAoAVlFdThwedzYhoHQNVAUPPnZl0wTx3dsRfF4iOeX8O7zO0hYEroeZcM1Mykvy2LXnib+57fvMjpioKpZ2FaEefOmEgxeQIwgXbGIDFBdXYjPLaMofto7NF59tZUDB0dJptyoyvgKm6bEwUMdjGhBvHOXEKk/Rqqr+9xouLCJRUYZio2S1j3E0y6Q3AhZYFsGdmUp9sgI8olOjK4Y7piGPmox1tKFpDgYKinllKUSV3UkVTuPmUoCWb7gdwGkFZl23U9q1gxSfh9D0RgnjjXQ2tVFW1srw6PDOJbNA92D5vCB7mU4koQJw2YkUufKYRPnVYaHSO7cgTyrhtODaQ4dHUTgIJ3W6ezsQ5JTPPDAdfztN29mw4aZuN0ySCmqqwvG1ctl5kvlC9skZGzbZubMYqqnZ2GZFoYhoTkcpNMxLDNB2ohg2Uk0TaW5K8zhxn5cd91BcjCE3HASJpJfskPHXzOX/twMmopsWrJ1BgNeYgE3hqJiLq4jlpfBWHc3Ac1DQFJpa2ymZXiQcEGQbpefYVMHRbscqcIlTTaWEIwpKqP5+cSycujoaqN/uBfTNAkEMkj4Pbw71MWo08EwEHZI9FlRYgMDmKkUut+LHvBfAM7YxrfINgXarHnsP9DJaMhAURSmVRewcNFMSkqKKS7MY9GiaqZNy8cy4xQVBamtnXrF8W/1rESepRwSQgiPx0FFeQYH64fw+lRyshX8fg8VZSV4PSqmofDiq8dIWipvvnqUG677NL5pVbB3P/ayxZCViSTLJGWZk4pCxzQngbSH2fNWo3j9eIqLiSRTBFctxxONYiVTuIK5pBwyYxk+3PmlRPUsQmMGaescVcj5LA0X60fTFrQODFO3fB7lLgmtvYXKmtkoDp1gMIPTIyFc85cQqp1PUganKuMcC/H8r35F8czZVEyfRtWCunPn6+ym/43XKamayoCezbbdB1BVB7YSYenSKdx77yra2wf4t+/9imPHhhgYVJDwMLu2mMLC4BWnwdWLCWcURcHplFl39Wy2butAkgy+dP91zJhRwFhohPy8HCxb8OrGAzjSHo6cGOGJxzbzuY/czOijP0Pbsw3P9beAEARKy7j1m/8fhpEkFY8RMi3CsTiegQGEgNbmRsZGQ7jdfgrRqaipYWR4EN2hI8t+pLZeLNtmeCSMZY1zlvi9bhwOlWQyRdqwME0bVZUw0iaWpJJIp8kqLKT5TDsoGm63B4/Xy9QlC3A4HDicTmLxJMeO1VM1tZq1IyGcTifejMC5yDKRIPXam7iTgvQNN/H2gTZOnglhWBrTpuaiqiqvvrYbVZW4+uplTK+O89gfj5BMjPKJT171fsycl39VVRZQVeln9542fvXoDlYsK2b50hJ6+oZ56skD2JYfIyUwZZ3Hn65n5eKpFMydj3jlFRJTpuOcOQMkiUBBIW2nT7N99150v4/23l7WLl5O/9AQucWl5JdW4HF7kGUVw7ZQdAeqy83IUBTdpbFx02G6u0ewhYauqxQV+Jk2rYiDB5tIpWxShg3CwutxEAgEiURTlMwoZcnKFdiWhS/gR5JlfBkZJJMpRkfH6O7u5mjjaYajSSKRKKtXrMDp8YxzeZkmyf0HCO3aiffqq+nUM3lr43Zsw0XQJ7j/CysYGhlCAEVF2fzmN28STwRIxBMsWlTC1Kq8Dw24JEmSyMvzs2L5NE6dCjEwmGQ0lCArJ59HHtnK22+34PVkojtNwGYwpPL4swf5xsdWE9l/CPvnj1Ly8D/DhNRk5+SwYP5CcvLzQZbx+Xz88QffZfXiZVyz/CpUWUZSlHG2nwlVISkDpE0LCZXiohxAITPTQyKeZGhkjOrqEnTdgWFaqKpMLBYlw+/F63VO5OezLlA5o2NjPP32m7h0lVuuWk9ZeRnDIyPEozE8Pu+5tMTgIGzeStLnJf8jt/P4d1+hrTOJKussWZxPdraLh//9dWyh8bWv3shNN63mW//4OrrD4tZbFl6cP5EuC/j5s+DnXFCFq6+u5be/30wi4WHenGm8+toRDh4K4fU4icfbUBQJzeEhJ6eATVsaWXHVVGpvvh33z35H5IlncH/hXmRVxZeRQbXfx/GmU7y1ezuqQyUjJ5v606eYN7OGorw86o8fo2ZqNS7nOGCVFcVUVhRfIg2RaJz+gVEqygouYti8lExnNBxGlVV8XjfN3Z28dmAni2bM4mfPPUG2O4ObVq+hvKz0PHo+6HvySbRTjUz51t+z6/AZtm7tQhIalhqlb6SbvLxsZs2qZseuZgzDxDRkDCPFwgX5zJtX8QFZ3S4YBJLOjrw95Pe7cToVtm8/xbYdvRw90oHXHeVrX13DN75+PTfdOJ9AhoM9u5sxTZXhwQGW3LoSb34W8Y2vkbItnFOnjUuvEAwND9E7OEBOVjY3rVxHMp3G5XSSG8zkB0/9gYONJ5heVsHuY4f57asvE/T6yfIHMEyLA0dOEUskae3oYWg4TE9vP32DI0iyhNftxrQsdjUc40+b3qIwO4eTHWf45yf/G1UISvMKae3pZn71LNbMWcBYJIIqKcyZOQPdMc6jJZkm4c3vYD3/J1w33UJnXhn/+v3XGIl6cKoJPvXJJcyqyaC7q5ebb1rGTTfOIyMjwLf+8TF0h4d77llK3bwp53tS0uVVyhUk5Gzj5rp1Nbz6+gkajhuoSoq7717GlMpcfvhfL6BpMp/97AY2vn2SgX6VI6ci/PZ32/jSF9didffCxl1Es7Pxr12LLMvUVM9g1rTpjMUi/Prl5zjV18NwNExJfj7L59TR3NNB9+AAuZmZpCWDP73zBpn+uykrLCKeiGGYafr7R8fJgYWJ1+dhLOKmKD+Hw80t/O6dV7hq5my8HjdNR+uZVlJKeVEh/cODbDm8j6gtSKUS3L5uPQ5VxeFwjOd9UikSWzYT/cPv8a67htDMOn7531to7Uzj0GDpskIKitz09UepmVXG8eNNHD7SzoEDg5iGTs2sAEsWTX3PJ+6D8BZ+G3jI43GTlRVk65ZDCAE33DiH1rYeEok0paVZaJpOc1sn8XAKLJ2Wlh76BwdYd+8txPr6SLy+EfJycJWXgRDIsoymafg8HiqLSinNy+Xd44do6GxjZkkFc6dOpzArh+xAJqqqEnB7kSV5fGwxM4OK0gJKi/MpLy1kLBzGH/BhWCYdQ30U5eQxb8p08jMzycnI4HRPJ0dbTmObNivnLSDL52deVTWZfj+qqo73gJsmsc2bGX78cVxLV2FcezO/f76eLTu7kCQHU8qdfP0bN2GYSX71yMu0NI8yv24GyaTG3j09OHWJT3x8KYsWT5usab4X3d5lAT/P333IsiyKijJoO9PL8RN9WGaUv/nrW4jExqirm85//ug57vvsBqZXl7Nz62l0R4DjHcNEoyFW3XszoZNt2M88RzLDjXfq1HGCdSTyM7Mpysrm7d3beafhAKOjo6ybvwjTMvje7x+hd2iYO9asp7ywiIGREdq6uzjQeJyh8AjRVJxth+tBU7Btm8KcXGaVV6DY8N0n/kDP6BArZ9fR3tPN1vp6Orq7qZtWzdq6Rfg9nkkePElRGNu8g7E//BH38pXkPPglHv3NNl5++wyS7CQWHeYTH59PaCxOVVUxC+pq+OMT77LxzWMcPdKPLMOaVZV88f4N48SS55LrVySVVB584Cvvxbj3bVmWH1IUmfz8AMePd9LQMEDz6W5qZ5dz+MhJbrtlKbLq5pe/eodoROBSvUiWSmPrEIl0nKX33YoVTaJufZvwQD96SSmK240kjw9MTS0tpzyYw+0r11GUmc9TW9+g14ywfNpsFtfMRpZlMnw+phQXc6D5JK/u28Kx1kZau3uoq6zmmiVLcU3UJN0uN72xMXaePIpHUrht5TqmF5WwYPoM5kybOd6tK0lg21gjQ3T/4Wm0Zzehrb6K1Lp1PPLrd3nt5dPEYzZen8XNN1ZSVJrDH/+4l9dfP8iihVO5/rqFnDgRIhwR5OdbfOdfPkYg4LmYLpQrA/7+BDUTBtRFOpXgyJE+TpwaoKe7h3XramnvGOG733+N0EiaQIaON6AwOjaGUBx0dA9hphIs+Og1SA4nqb312B0dpD0enLnZyIqK7nBQml9E0J+BZRlgWsytGJdGh6Zd8NR5HC7mTqnmpuVryfX4qJ06jaD/XMCiKgqFwUxy3F6yAwFK8gsozMmlMCcPVVHGJzhSKWKHD2K88AJm/VGk9WuJzpvPrx/bzaZ3e4lFbZy64J6Pz2PJ0moajvXR0jaMLRxs234Sy1Rpbe3F7RZ84+s3MfdCz0R6P2Y3qanx5AfhyBdCCMZCMX74n8/x4kstlJdn8zffvJot2w7w3LMnmDdnCp/+9FX4/U6aTvfy45+8jWm50CSDubOCfPXBDeSHBwi/8jLO0CDuFavQ16/DUVAwni8fnyOf6FaSLsmbnG/Iz/IAnCXmvbgDWJzHPYVtjxcaZJlYZzvmaxtJHj5Ayu+j4NOfpSWl8ctfv8ueg/3IshtVFWRnS3z9G+vZtfcEf/rTQRYunMrq1bP5yU/fRJMzMNID3HHHAr705Rtxux2cN8AtfTC38P1f35Yk6SGXy8HcuZXs23+Kjs4ooVCcu+9axa5d9XznOx/h2PFG/vDEJu66cwkul5OD+1uRJDdDoxJ79h4ma0ohdR+5AT0aJfTGm4R2bUOVwVlUDM5xhiF5YipCkuUrMoKeBfpyUiRJ47y08tkASpaRxsKMvPUG/T//IeJ0J/qKVeTd/0X2tYb4p399kYamNKrmIxYfZcmSUj7/hWUMDQ1x443LOHz4OFVVWVRVFnHgQCfhcJhFi4r58lduIBj0nL/gH4gAUnnwwQeQPtjR35bgIZdLp66ujJ07D3G6McSxhtPk5jtYeVUtv/jly7S1jZJf4CMn24vullAUmdH+MYZHDA4d62Q4Eaf85mvwLa7DOzyIe9c2+rdtIRkeQVU1NM2BUNXJnsU/h4RYMgyIRkm2NDH22ouMPf4YmSePkzmzFunTn2W4eg4/+umb/O53hxmO6ViWRVmJi5XLK+gbaCM3101Wlo8TJ0/zyU9uwOcL8PQzh2ls7GVKuYu//uvbqKoqvGy++33ZTS9Hoyfeg7ZJCCFMy+Ldd4/y05++TkenhNsd4Xvf+xQ7dx1AkhTuuG01Zzp6Cfi9dHeP8dpL9TQcG8OyZBTZYlpFgHXXTqduVj6FqVE4fgRP8xEiw2E8JVWkqqcilZTjyM9Dy8pC8frg7ALI41RGCDGuLgBhmYjwGNbwENHeXuz2dvSmVuItTfgK84lPn4a+cBnDrkze3nmat986QXtXCiwJy04wd14+ixcXc9ddaxgaGqW1pZNZNZVs21bPs88fJBx20tcXp7jIyT//0y0sWlR9ESyCD7p5yYcGfEJPilQ6zYEDTfzkZ5s5eWKQFVdV8tGPLCIajhKNh1m3ZhH7DjbQ3z/Cgrp5fOWBP2CYHoRlj89QGnFKywKsXVPF4gVlzM51YHZ1Ejp0hMETx8lOC/IDPmSnCzMQhKAf1edC6A6ErCJMAxJJ0tEoUjyCFh6BVJqhRJKo5sFVVEJw2RKs7HxawiY7drWya18XJ08NYwkJISfJzRbcffdVVFVlI8tw5EgD69ev5PU3dlNWWkB2Tjb/8vCbjAyblJbofP1rG1ixYsb5JDTS+fXKDwb4qZOXTbW8185DYkLSLcti+/bDfOc7zzM0bBPMzCQ3F378n59h48bdON0OVq+az9Ztp/jFL15h0aJadKebN189iSa7QRK43DKanmb5/HyWL69m7pwKAh4Nb3snVmsL4bY2wt3dWGNjKGYaYcSRESC5iKbTyEEfejADV1EhGaXlOKdVkyosJpS02b6nmd27GjlQ38fwqMA0ZDTVQnMkuO6mmXz5/g20tvbwwx88yde+9jF6etsIh8fIy6/kkV+/jW166OkdIz/fyd/93a2sWD4DVb1UZ59j3xTvyz8rnZ4AXHxIwM+6LkIImpraeeihF2hqTlJaksE//sM1jI6FOHSohWuvqeOr3/g5d9yxnI/efTVtrQN89RsvkpMVYHQ0wljYxOnykEgk8LsgK2iRU+hgyeKZrFo1h8xML7oqoyRipONxsIzxaTRlvJiteTyYDhcpUxCJJHjrrXoOHmiipz1E75ADCx1Fk0GyUFWDG2+oZumicpxuB6++spVPffJa/v17r6CpCj/6z0/zox8/hi2CnDgR5UxLD5VVAf7u729n3kSe5HI6+3z25A/kFn5QynHpMscJ2xZigrHzN7/ZxK7dfWQENO7+yHyqq4vp7uwlkYqxdvUijp88RTwm87vf7+bbD32MPz6+h+07ekgnLWTFxOFwIssKYKLJNsJMEgw4KSry4/U7cHs13C4nTl3HSKYxEhZDI2OMjKXp6IgQjSeRFDemAEkREzOSGmUlTlQ1wpy5FaxdM4tIJMKuPW288up+vvbAtWiak0cffZP5ddNBUtm8uRGnDjNnZvLVr95ITU35ZAmSy+12dwly70Ff2NR06rK7eHxQs3tWvYyPF47y1NNbef65vYCP7Bwv69dPo7Qki0h0lIULqtn0ziFCo0nuuH0VX7z/vwmFvNiWSXaOwdKlVXR2DNHSFiKZkDENB0IoGEYaRbNRZIGCjCpJpI0UkqwiHBqypGKmTIQw0DQHXo9MSanGtOp8jDTk5TmZUpnL0NAIy5bVMjg4Bii88OIuWlqHeOArN/GH32/nWEMUyzbJCMD1103jnntWUlAQvGDXEz6QT3dlnX4B4H/OFljiouAomUyzd+8pvv/95+gfkPB6g+gOBVnp55vfvJPTzW1cs34RP/35G2zZ3INlB4AU935qGh//xGri8TSbNx3i8OEWfL4sOtpHaGkbZixioOkusJLYRhRFtZE1Hd3lxEoryJLEXXfN4/ChLvLyfHzjr66hoaGVzCwf4UiUWTOn8PB3f00ykcC0ZG66fgU1tTP5+Kd+RW5W5gRLtEIw0+arD17D6lWz0HX1MgmpDwK4/QErPhOtX3/mtimSNL59l1i9eg6zZpXwq19tZPM7nfT2JQlm+Nm0qZnKygDBjACh0TAul4NozEZTbe66eyWvv76RkZEwd911M0uXTqWl5Qxf+tIqvvf9ZwlkBFi5Yg5HjzZz3XXz8Ptd7N59ElmWiERS7NrVyCc+sYwjR59iODRCMpnmxz99nsqqbL70xds5erSJO29dT3fPCLNrK9GdOr/57VZMQ6K/P4XbCcuXZ/ONr99KQcH4nj4TQc3/eqONi5JXD1ywdn+GZF/YdyHL3xZCPOTxuKmtLSc3z8VYJMToaIKGI50MDyUQwuSG6xej6zqnT/eiO9Lcd98qcnLyqKyspKGhhXl1M3h32y7KyotxO1VUNcXVVy+gqCjIxo172bTpMLfdtpwTJ9qora3k2msXsPmdwzz3/DFi8Rh337WUlGHS3z/GzBnl7N7dwIrlC3jmmQOMjKb503P72bmrBb/Xw9w5eXzyE4t48IEb8fvdk1N5l4fkg6qUK0i4xF9+Z8mz+2plZvrErbcsZuGiaezacYLt209x5HAPP/3pZqZVF+P35iFLKtXTS+nrC/Hww8+RTEroeoJrrllERkY2nZ1D5ORmMmduFV1dA3i8TuoP99JwfJB77okRTyhs2nyMBx+4gU3vnEBTHRgpOHiwnZtuWMz06iKGh5Ps3j3AQP9WDtQPsn1nLx6PxLLFJaxeXcOKFTPIyw2c6ym8rIvxYcTxyqiq56sQ8b+U7st9s6LIoqggg9tvX8K6dbM5fryLZ/+0g737TpM2hlAUL2fORPjHf3qJ1tNRDANWrymlp2cIRXYyOJigu3uYv/qruTz7p63MnFXGjOocsjJ95OZm0tEepbmli3g8RWZmFoIwAp3nXziKbQu2bTtJc+sIA4Nx+gZOoalJVq+ayq23LKSmpphAwI2iyB8wJyK9n6Bd4nxcckxz46nJHm7+8oBfaFHPu6iWln6eeGonB/a10deXJG3aOFQXspBxeSEjKCgqDBCPybR39PKLX3yeXz/yDoYZ44tfuh6v28E7Wxr47nc34vN5+ehHFrBj15nxHm1ZQVFMJDuFYRg4nAb5hTp1ddP5+EdXUVVVMNlM9MF1tfQhALev7KWc/mDp2T8b6PfC37Js2tr66e8PcaZ9kEP1bfT3R4hGYWg4SSyWQJIlhC3w+nzEIglsAZnZDoSdIBK2ATeWaWDbBpKq4ve5yMn2oGoWeTkaCxdWUVwcZPr0UvLzgxcHJBfsnfze9UiJD+ksf/Bcyl8S6PeyEWcj1bN7N4VCUcLhKKFQmvb2fkZHo4TDMaLRNMmkTSSSJp6wME0LTRM4dQWPx4XuVHG7FDIzveTmZlBamoPP58Dnc5OV5b/gEb9Ymj844PKHuOsru4UfaGuw/yvAL7ppcT6znGVZ2LaNZY1vYWMYFum0hWHY2MJGVRQUZZxgQFUVHA4VVR3XxWe5uc4CPFG0uNLGiZNXeWW8pQ9pND+oH/5/q0beT/dJZxuQzgIly7JQVdD1y+coLmecJvfBvEKX7aXHf1Cx+cuImfp/Dar4CyzChwPr0k0B3zuQkz4A6OLPBP7SBfj/ARQdkTRsq45fAAAAAElFTkSuQmCC" alt="School seal"></div>
<form onsubmit="return A.login(event)"><h2>SIGN IN TO CAREDESK</h2>${notice()}
<label>Role</label><div class="seg"><button type="button" id="r-doctor" class="${role === 'doctor' ? 'on' : ''}" onclick="A.role('doctor')">Doctor</button><button type="button" id="r-nurse" class="${role === 'nurse' ? 'on' : ''}" onclick="A.role('nurse')">school nurse</button></div>
<label>Username<input type="text" name="u" placeholder="Enter username" value="${E(saved)}" required></label>
<label>Password<input type="password" name="p" placeholder="Enter password" required></label>
<div class="lrow"><label><input type="checkbox" name="rem"${saved ? ' checked' : ''}> Remember this device</label><a href="#" onclick="return A.inquiry('password')">Forgot password</a></div>
<button class="btn" id="go">Continue as ${role === 'doctor' ? 'Doctor' : 'School Nurse'}</button><small id="hint">Authorized clinic staff only<br>Demo: mreyes / doctor123 &nbsp;·&nbsp; acruz / nurse123</small></form></section></div>${inquiryType ? inquiryModal() : ''}`;
}

// ===== views/inquiry-modal.js =====
// MYSQL: small pop-up for "Contact admin" / "Forgot password". The message is saved in the inquiries table.
function inquiryModal() {
  const t = { access: ['Contact admin', 'Tell the clinic admin who you are and what access you need.'], password: ['Forgot password', 'Tell the clinic admin which account needs a password reset.'] }[inquiryType] || ['Contact admin', ''];
  return `<div class="modal" onclick="if(event.target===this)A.inquiryClose()"><form class="panel" role="dialog" aria-label="${E(t[0])}" onsubmit="return A.inquirySend(event)"><h3>${E(t[0])}</h3><p class="note">${E(t[1])}</p>
<p class="flash err" id="inq-err" hidden></p>
<label>Your name<input name="n" maxlength="100" required></label><label>Email<input type="email" name="m" maxlength="100" required></label>
<label>Message<textarea name="g" rows="4" maxlength="2000" required></textarea></label>
<div><button class="btn">Send</button> <button type="button" class="btn ghost" onclick="A.inquiryClose()">Cancel</button></div></form></div>`;
}

// ===== views/shell.js =====
function shell() {
  const nav = [['dashboard', 'Dashboard'], ['records', 'Student Records'], ['status', 'Record Status'], ['clearance', 'Clearance Approval'], ['analysis', 'Record Analysis'], ['insights', 'Health Insights'], ['profile', 'Profile']];
  const v = { dashboard, records, form, status, clearance, analysis, insights, profile }[view]();
  return `<aside class="side"><div class="brand"><b>School Clinic</b><span>Management System</span></div>
<nav>${nav.map(([k, l]) => `<button class="${k === view || (view === 'form' && k === 'records') ? 'on' : ''}" onclick="A.nav('${k}')">${l}</button>`).join('')}<button onclick="A.logout()">Logout</button></nav></aside>
<main><header class="top"><div><h2>${v.title}</h2><p>${v.sub}</p></div><div class="right"><div class="usr"><div><b>${E(me.name)}</b><span>${isDoc() ? 'Doctor' : 'School Nurse'}</span></div>${ICON.user}</div>${v.action || ''}</div></header>${notice()}${v.body}</main>${viewId ? viewModal() : ''}`;
}

// ===== views/dashboard.js =====
function dashboard() {
  const c = s => db.stats.counts[s] || 0; // MYSQL: counts come from SQL
  const recent = db.activity; // MYSQL: latest rows of the activity_logs table
  const now = new Date(), y = now.getFullYear(), m = now.getMonth(), days = new Date(y, m + 1, 0).getDate(), pad = new Date(y, m, 1).getDay();
  const marks = db.stats.calendar; // MYSQL: exams per day of this month
  let cal = ['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => `<i>${d}</i>`).join('') + '<span></span>'.repeat(pad);
  for (let d = 1; d <= days; d++) cal += `<span class="${d === now.getDate() ? 'today ' : ''}${marks[d] ? 'mark' : ''}" title="${marks[d] || 0} exam(s)">${d}</span>`;
  return {
    title: 'Dashboard', sub: "Welcome back, here's what's happening in the clinic today.",
    body: `<div class="stats"><div class="stat total"><span>Total Student Records</span><b>${db.stats.total.toLocaleString()}</b></div>${ST.map(s => `<div class="stat ${s}"><span>${s}</span><b>${c(s).toLocaleString()}</b></div>`).join('')}</div>
<div class="two"><section class="sec"><h3>Clinic Schedule <span class="pill">${now.toLocaleString([], { month: 'long', year: 'numeric' })}</span></h3><div class="cal">${cal}</div></section>
<section class="sec"><h3>Recent Activity</h3><ul class="feed">${recent.map(r => `<li class="${r.action === 'approved' ? 'approved' : ''}"><span>${E(r.description)}</span><time>${tm(r.t)}</time></li>`).join('') || '<li>No activity yet.</li>'}</ul></section></div>`
  };
}

// ===== views/rows-html.js =====
function rowsHtml() {
  const k = q.toLowerCase();
  const list = db.rows.filter(r => (!k || r.name.toLowerCase().includes(k) || r.no.toLowerCase().includes(k)) && (!F.year || r.year === F.year) && (!F.course || r.course === F.course) && (!F.test || r.test === F.test) && (!F.status || r.status === F.status)).sort((a, b) => a.id - b.id);
  return list.map(r => `<tr><td>${E(r.no)}</td><td>${E(r.name)}</td><td>${E(r.year)}</td><td>${E(r.course)}</td><td>${E(r.test)}</td><td>${st(r.status)}</td>
<td><div class="acts"><button class="ic" aria-label="View ${E(r.name)}" onclick="A.view(${r.id})">${ICON.eye}</button><button class="ic" aria-label="Edit ${E(r.name)}" onclick="A.edit(${r.id})">${ICON.pen}</button>${isDoc() ? `<button class="ic del" aria-label="Delete ${E(r.name)}" onclick="A.del(${r.id})">${ICON.bin}</button>` : ''}</div></td></tr>`).join('')
    || '<tr><td colspan="7">No records match. Clear the filters or add a new record.</td></tr>';
}

// ===== views/records.js =====
function records() {
  const sel = (k, label, list, lab) => `<label>${label}<select onchange="A.filter('${k}',this.value)"><option value="">All</option>${list.map(x => `<option value="${E(x)}"${F[k] === x ? ' selected' : ''}>${lab ? cap(x) : E(x)}</option>`).join('')}</select></label>`;
  return {
    title: 'Student Record List', sub: '',
    action: '<button class="btn" onclick="A.add()">Add Record</button>',
    body: `<div class="filters"><div class="search">${ICON.search}<input aria-label="Search student records" placeholder="Search student records..." value="${E(q)}" oninput="A.filter('q',this.value)"></div>
${sel('year', 'Year Level', YEARS)}${sel('course', 'Course', COURSES)}${sel('test', 'Kind of Test', TESTS)}${sel('status', 'Status', ST, 1)}</div>
<div class="scroll"><table><thead><tr><th>Student No.</th><th>Student Name</th><th>Year Level</th><th>Course</th><th>Kind of Test</th><th>Status</th><th>Actions</th></tr></thead><tbody id="rows">${rowsHtml()}</tbody></table></div>`
  };
}

// ===== views/form.js =====
function form() {
  const r = editId ? db.rows.find(x => x.id === editId) : { no: '', name: '', year: YEARS[0], course: COURSES[0], test: TESTS[0], date: dstr(), status: 'pending', remarks: '', height: '', weight: '', bp: '', hr: '', vision: '', hearing: 'Normal' };
  const sts = isDoc() ? ST : ST.filter(s => s !== 'approved' || r.status === 'approved');
  const f = (n, l, extra = '') => `<label>${l}<input name="${n}" value="${E(r[n])}" ${extra}></label>`;
  return {
    title: 'Add / Update Student Record', sub: 'Enter or update the student’s health record details.',
    body: `<form class="panel wide" onsubmit="return A.save(event)">
${f('no', 'Student No.', 'placeholder="CA202505407" pattern="[A-Za-z]{2}\\d{9}" title="Use the format CA202505407 (2 letters + 9 digits)" required')}${f('name', 'Name', 'required')}
<label>Year Level<select name="year">${opts(YEARS, r.year)}</select></label><label>Course<select name="course">${opts(COURSES.includes(r.course) ? COURSES : [...COURSES, r.course], r.course)}</select></label>
<label>Kind of Test<select name="test">${opts(TESTS, r.test)}</select></label>
<label>Status<select name="status">${sts.map(s => `<option value="${s}"${r.status === s ? ' selected' : ''}>${cap(s)}</option>`).join('')}</select></label>
${f('date', 'Date of Exam', 'type="date" required')}<span></span>
<label class="full">Remarks<textarea name="remarks" rows="4" placeholder="Initial physical examination for school clearance.">${E(r.remarks)}</textarea></label>
<details class="more"${r.height || r.bp ? ' open' : ''}><summary>Test details (optional)</summary><div class="dgrid">
${f('height', 'Height (cm)', 'type="number" min="50" max="250" step="0.1"')}${f('weight', 'Weight (kg)', 'type="number" min="10" max="300" step="0.1"')}
${f('bp', 'Blood Pressure (mmHg)', 'placeholder="110/70" pattern="\\d{2,3}/\\d{2,3}" title="Use the format 110/70"')}${f('hr', 'Heart Rate (bpm)', 'type="number" min="30" max="220"')}
${f('vision', 'Vision (L / R)', 'placeholder="20/20" pattern="\\d{1,2}/\\d{1,3}" title="Use the format 20/20"')}${f('hearing', 'Hearing (L / R)')}</div></details>
<div class="full"><button class="btn">Save</button> <button type="button" class="btn ghost" onclick="A.nav('records')">Cancel</button></div></form>`
  };
}

// ===== views/status.js =====
function status() {
  return {
    title: 'Record Status Management', sub: `${isDoc() ? '' : ' Nurses can move records between pending and ongoing; doctors approve.'}`,
    body: `<div class="board">${ST.map(s => { const l = db.rows.filter(r => r.status === s); return `<section class="col ${s}" data-s="${s}"><h3>${s}</h3><div class="cards">${l.map(r => { const lock = !isDoc() && s === 'approved'; return `<article class="card" draggable="${!lock}" data-id="${r.id}"><dl><dt>Student No.</dt><dd>${E(r.no)}</dd><dt>Name</dt><dd>${E(r.name)}</dd><dt>Kind of Test</dt><dd>${E(r.test)}</dd></dl><span class="badge ${s}">${s}</span>${lock ? '' : `<select aria-label="Move ${E(r.name)}" onchange="A.move(${r.id},this.value)">${ST.filter(x => isDoc() || x !== 'approved' || r.status === 'approved').map(x => `<option value="${x}"${x === s ? ' selected' : ''}>Move to: ${x}</option>`).join('')}</select>`}</article>`; }).join('')}</div><p class="drop">Drag here</p></section>`; }).join('')}</div>`
  };
}

// ===== views/clearance.js =====
function clearance() {
  const queue = db.rows.filter(r => r.status !== 'approved');
  const r = queue.find(x => x.id === selId) || queue[0];
  const head = { title: 'Medical Clearance Approval', sub: '' };
  if (!r) return { ...head, body: '<p>Nothing is waiting for approval.</p>' };
  const d = (v, u = '') => v !== '' && v != null ? E(v) + u : '—';
  const [yy, mm, dd] = r.date.split('-').map(Number), ro = isDoc() ? '' : ' disabled';
  return {
    ...head, body: `<div class="split"><nav class="queue">${queue.map(x => `<button class="${x.id === r.id ? 'on' : ''}" onclick="A.pick(${x.id})"><b>${E(x.name)}</b><small>${E(x.test)}</small></button>`).join('')}</nav>
<div class="panel wide detail"><div class="full head"><div><b>${E(r.name)}</b><br>${E(r.test)}</div>${st(r.status)}</div>
<dl class="grid full"><div><dt>Student No.</dt><dd>${E(r.no)}</dd></div><div><dt>Year Level</dt><dd>${E(r.year)}</dd></div><div><dt>Course</dt><dd>${E(r.course)}</dd></div></dl>
<h3 class="full">Test Details</h3>
<dl class="grid full"><div><dt>Date of Exam</dt><dd>${new Date(yy, mm - 1, dd).toLocaleDateString([], { month: 'long', day: 'numeric', year: 'numeric' })}</dd></div><div><dt>Kind of Test</dt><dd>${E(r.test)}</dd></div>
<div><dt>Height</dt><dd>${d(r.height, ' cm')}</dd></div><div><dt>Weight</dt><dd>${d(r.weight, ' kg')}</dd></div><div><dt>Blood Pressure</dt><dd>${d(r.bp, ' mmHg')}</dd></div><div><dt>Heart Rate</dt><dd>${d(r.hr, ' bpm')}</dd></div>
<div><dt>Vision (L / R)</dt><dd>${d(r.vision)}</dd></div><div><dt>Hearing (L / R)</dt><dd>${d(r.hearing)}</dd></div></dl>
<div class="full"><b>General Remarks</b><p>${E(r.remarks) || '—'}</p></div>
<label class="full">Doctor's Remarks<textarea id="dr" rows="3" placeholder="Enter your remarks here..."${ro}>${E(r.dr)}</textarea></label>
<div class="full"><button class="btn bad"${ro} onclick="A.decide(${r.id},false)">Reject</button> <button class="btn"${ro} onclick="A.decide(${r.id},true)">Approve</button>${isDoc() ? '' : '<p class="note">Only a doctor can approve or reject clearance.</p>'}</div></div></div>`
  };
}

// ===== views/analyse.js =====
function analyse() {
  const total = db.rows.length, c = { pending: 0, ongoing: 0, approved: 0 }, fl = [];
  db.rows.forEach(r => {
    c[r.status]++; const why = [];
    const m = (r.bp || '').match(/(\d+)\s*\/\s*(\d+)/);
    if (m && (+m[1] >= 130 || +m[2] >= 85)) why.push('Elevated blood pressure reading');
    const v = (r.vision || '').trim(); if (v && v !== '20/20') why.push('Vision screening follow-up');
    const note = (r.remarks || '').trim(), t = note.toLowerCase().replace('no abnormalities', '').replace('no abnormality', '');
    if (/abnormal|follow-up|follow up/.test(t)) why.push(note.replace(/\.$/, ''));
    if (why.length) fl.push({ name: r.name, reason: why[0], t: r.t });
  });
  const p = n => total ? Math.round(1000 * n / total) / 10 : 0;
  return { total, c, p: { pending: p(c.pending), ongoing: p(c.ongoing), approved: p(c.approved) }, fl, fp: p(fl.length) };
}

// ===== views/analysis.js =====
function analysis() {
  const a = analyse();
  return {
    title: 'Record Analysis', sub: '',
    body: `<div class="stats"><div class="stat total"><span>Total Records</span><b>${a.total}</b></div><div class="stat approved"><span>Approved (${a.c.approved})</span><b>${a.p.approved}%</b></div><div class="stat pending"><span>Pending (${a.c.pending})</span><b>${a.p.pending}%</b></div>
<div class="stat ongoing"><span>Ongoing (${a.c.ongoing})</span><b>${a.p.ongoing}%</b></div><div class="stat flag"><span>Flagged (${a.fl.length})</span><b>${a.fp}%</b></div></div>
<div class="two"><section class="sec"><h3>Records by Status</h3>${ST.map(s => `<div class="bar-row"><span>${cap(s)}</span><div class="track"><i class="${s}" style="width:${a.p[s]}%"></i></div><b>${a.c[s]}</b></div>`).join('')}</section>
<section class="sec"><h3>Flagged cases for follow-up</h3><ul class="feed">${a.fl.map(f => `<li><span><b>${E(f.name)}</b><small>${E(f.reason)}</small></span><time>${tm(f.t)}</time></li>`).join('') || '<li>No flagged cases.</li>'}</ul></section></div>`
  };
}

// ===== views/profile.js =====
function profile() {
  return {
    title: 'User Profile and Secure Logout', sub: 'Manage your account details and sign out with confidence.',
    body: `<div class="sec" style="max-width:560px;margin-bottom:1.5rem"><h3>Account Overview</h3><dl class="info"><dt>Name</dt><dd>${E(me.name)}</dd><dt>Role</dt><dd>${isDoc() ? 'Doctor' : 'School Nurse'}</dd><dt>Username</dt><dd>${E(me.user)}</dd><dt>Email</dt><dd>${E(me.email)}</dd><dt>Phone</dt><dd>${E(me.phone)}</dd><dt>Last Login</dt><dd>${E(me.last)}</dd></dl></div>
<form class="panel" onsubmit="return A.pw(event)"><h3>Change Password</h3><label>Current password<input type="password" name="c" required></label><label>New password<input type="password" name="n" minlength="8" required></label><button class="btn">Change Password</button></form><button class="btn ghost" onclick="A.logout()">Logout</button>`
  };
}

// ===== views/view-modal.js =====
function viewModal() {
  const r = db.rows.find(x => x.id === viewId); if (!r) return '';
  const d = (v, u = '') => v !== '' && v != null ? E(v) + u : '—';
  return `<div class="modal" onclick="if(event.target===this)A.closeView()"><div class="panel" role="dialog" aria-label="Record details"><h3>${E(r.name)} ${st(r.status)}</h3>
<dl class="info"><dt>Student No.</dt><dd>${E(r.no)}</dd><dt>Year / Course</dt><dd>${E(r.year)} · ${E(r.course)}</dd><dt>Kind of Test</dt><dd>${E(r.test)} on ${E(r.date)}</dd><dt>Height / Weight</dt><dd>${d(r.height, ' cm')} / ${d(r.weight, ' kg')}</dd><dt>Blood Pressure</dt><dd>${d(r.bp, ' mmHg')}</dd><dt>Heart Rate</dt><dd>${d(r.hr, ' bpm')}</dd><dt>Vision / Hearing</dt><dd>${d(r.vision)} / ${d(r.hearing)}</dd><dt>Remarks</dt><dd>${d(r.remarks)}</dd><dt>Doctor's Remarks</dt><dd>${d(r.dr)}</dd></dl>
<button class="btn ghost" onclick="A.closeView()">Close</button></div></div>`;
}

// ===== views/wire-board.js =====
function wireBoard() {
  let drag = null;
  document.querySelectorAll('.card[draggable=true]').forEach(c => c.addEventListener('dragstart', () => drag = c));
  document.querySelectorAll('.col').forEach(col => {
    col.addEventListener('dragover', e => { e.preventDefault(); col.classList.add('over'); });
    col.addEventListener('dragleave', () => col.classList.remove('over'));
    col.addEventListener('drop', e => { e.preventDefault(); col.classList.remove('over'); if (drag) A.move(+drag.dataset.id, col.dataset.s); });
  });
}

// ===== actions/action-object.js =====
const A = {};

// ===== actions/nav.js =====
A.nav = function (v) { if (v === 'form') { view = 'form'; editId = null; viewId = null; draw(); return; } const pages = { dashboard: 'dashboard.php', records: 'student-records.php', status: 'record-status.php', clearance: 'clearance-approval.php', analysis: 'record-analysis.php', insights: 'insights.php', profile: 'profile.php' }; if (pages[v]) location.href = pages[v]; };

// ===== actions/role.js =====
A.role = function (r) { role = r; $('#r-doctor').classList.toggle('on', r === 'doctor'); $('#r-nurse').classList.toggle('on', r === 'nurse'); $('#go').textContent = 'Continue as ' + (r === 'doctor' ? 'Doctor' : 'School Nurse'); };

// ===== actions/hint.js =====
A.hint = function (t) { $('#hint').textContent = t; return false; };

// ===== actions/login.js =====
// MYSQL: api/login.php checks username, password and role against the users table.
A.login = function (e) {
  e.preventDefault(); const f = e.target, u = f.u.value.trim(), rem = f.rem.checked;
  api('login.php', { username: u, password: f.p.value, role }).then(j => {
    if (j.ok) {
      me = j.user; csrf = j.csrf; me.last = me.last ? new Date(me.last).toLocaleString() : 'First login'; view = 'dashboard';
      try { rem ? localStorage.setItem('clinic-user', u) : localStorage.removeItem('clinic-user'); } catch (x) { }
      location.href = 'dashboard.php';
    } else { err = j.error; draw(); }
  });
  return false;
};

// ===== actions/logout.js =====

// Open logout confirmation modal
A.logout = function () {
    drawLogoutModal();
};

// Cancel logout
A.cancelLogout = function () {
    const modal = document.getElementById('logoutModal');

    if (modal) {
        modal.remove();
    }
};

// Confirm logout
A.confirmLogout = function () {
    try {
        localStorage.removeItem('clinic-user');
    } catch (e) {}

    location.href = 'logout.php';
};

// Display logout modal
function drawLogoutModal() {
    if (document.getElementById('logoutModal')) return;

    const modal = document.createElement('div');

    modal.id = 'logoutModal';
    modal.className = 'modal';

    modal.innerHTML = `
        <div class="panel logout-panel"
             role="dialog"
             aria-modal="true"
             aria-labelledby="logoutTitle">

            <h3 id="logoutTitle">Confirm Logout</h3>

            <p>Do you want to log out?</p>

            <div class="logout-buttons">
                <button class="btn"
                        onclick="A.confirmLogout()">
                    Yes, Log Out
                </button>

                <button class="btn ghost"
                        onclick="A.cancelLogout()">
                    Cancel
                </button>
            </div>

        </div>
    `;

    document.body.appendChild(modal);
}

// ===== actions/filter.js =====
A.filter = function (k, v) { if (k === 'q') q = v; else F[k] = v; $('#rows').innerHTML = rowsHtml(); };

// ===== actions/add.js =====
A.add = function () { editId = null; view = 'form'; draw(); };

// ===== actions/view.js =====
A.view = function (id) { viewId = id; draw(); };

// ===== actions/close-view.js =====
A.closeView = function () { viewId = null; draw(); };

// ===== actions/edit.js =====
A.edit = function (id) { const r = db.rows.find(x => x.id === id); if (r.status === 'approved' && !isDoc()) { err = 'Only a doctor can edit an approved record.'; draw(); return; } editId = id; view = 'form'; draw(); };

// ===== actions/del.js =====
// MYSQL: deletes the medical record in MySQL (api/record-delete.php), then reloads the data.
A.del = function (id) { if (isDoc() && confirm('Delete this record?')) { api('record-delete.php', { id }).then(async j => { if (j.ok) { await loadData(); msg = 'Record deleted.'; } else err = j.error; draw(); }); } };

// ===== actions/save.js =====
A.save = function (e) {
  e.preventDefault(); const f = e.target, v = n => f[n].value.trim();
  if (v('status') === 'approved' && !isDoc()) { err = 'Only a doctor can mark a record as approved.'; draw(); return false; }
  const d = { no: v('no'), name: v('name'), year: v('year'), course: v('course'), test: v('test'), date: v('date'), status: v('status'), remarks: v('remarks'), height: v('height'), weight: v('weight'), bp: v('bp'), hr: v('hr'), vision: v('vision'), hearing: v('hearing') };
  // MYSQL: api/record-save.php saves the student + medical record (add when editId is empty, update otherwise).
  api('record-save.php', { id: editId || 0, ...d }).then(j => {
    if (j.ok) { msg = 'Record saved.'; editId = null; try { sessionStorage.setItem('clinic-flash', msg); } catch (x) {} location.href = 'student-records.php'; }
    else { err = j.error; draw(); const nf = $('form.panel'); if (nf) Object.keys(d).forEach(k => { if (nf.elements[k]) nf.elements[k].value = d[k]; }); }
  });
  return false;
};

// ===== actions/move.js =====
A.move = function (id, to) {
  const r = db.rows.find(x => x.id === id); if (!r || r.status === to) return;
  if (!isDoc() && (to === 'approved' || r.status === 'approved')) { err = 'Only a doctor can approve records or change approved ones.'; draw(); return; }
  // MYSQL: api/record-move.php updates the status in MySQL.
  api('record-move.php', { id, status: to }).then(async j => { if (j.ok) await loadData(); else err = j.error; draw(); });
};

// ===== actions/pick.js =====
A.pick = function (id) { selId = id; draw(); };

// ===== actions/decide.js =====
A.decide = function (id, ok) {
  if (!isDoc()) return;
  const note = $('#dr').value.trim();
  if (!ok && !note) { err = 'Add your remarks before rejecting, so the nurse knows what to fix.'; selId = id; draw(); return; }
  // MYSQL: api/clearance-decide.php saves the doctor's remarks and the new status in MySQL.
  api('clearance-decide.php', { id, approve: ok, remarks: note }).then(async j => {
    if (j.ok) { await loadData(); msg = ok ? 'Clearance approved.' : 'Record rejected and sent back to pending.'; selId = null; }
    else { err = j.error; selId = id; }
    draw();
  });
};

// ===== actions/pw.js =====
// MYSQL: api/password-change.php checks the current password and saves the new hash in the users table.
A.pw = function (e) {
  e.preventDefault(); const f = e.target;
  api('password-change.php', { current: f.c.value, password: f.n.value }).then(j => { if (j.ok) msg = 'Password changed.'; else err = j.error; draw(); });
  return false;
};

// ===== actions/inquiry-open.js =====
// MYSQL: opens the inquiry pop-up (type 'access' or 'password').
A.inquiry = function (type) { inquiryType = type; draw(); return false; };

// ===== actions/inquiry-close.js =====
A.inquiryClose = function () { inquiryType = null; draw(); };

// ===== actions/inquiry-send.js =====
// MYSQL: api/inquiry-submit.php saves the message in the inquiries table.
A.inquirySend = function (e) {
  e.preventDefault(); const f = e.target, b = e.submitter; if (b) b.disabled = true;
  api('inquiry-submit.php', { type: inquiryType, name: f.n.value.trim(), email: f.m.value.trim(), message: f.g.value.trim() }).then(j => {
    if (j.ok) { msg = 'Your message was sent to the clinic admin.'; inquiryType = null; draw(); return; }
    const x = $('#inq-err'); if (x) { x.textContent = j.error; x.hidden = false; } if (b) b.disabled = false;
  });
  return false;
};

// ===== start.js =====
// ===== insights (HEALTH INSIGHTS: Python ang nag-compute, galing api/insights.php) =====
let ins = null;
function insights() {
  const sub = '';
  if (!ins) return { title: 'Health Insights', sub, body: '<section class="sec"><h3>Loading…</h3></section>' };
  if (!ins.ok) return { title: 'Health Insights', sub, body: `<section class="sec"><h3>Python unavailable</h3><p>${E(ins.error || '')}</p></section>` };
  const bmi = ins.bmi.map(b => `<div class="bar-row"><span>${E(b.label)}</span><div class="track"><i class="approved" style="width:${b.pct}%"></i></div><b>${b.count}</b></div>`).join('');
  const flags = ins.flagged.map(f => `<li><span><b>${E(f.name)}</b><small>${E(f.reason)}</small></span><time>${E(f.date)}</time></li>`).join('') || '<li>No flagged cases.</li>';
  return { title: 'Health Insights', sub, body: `<div class="stats"><div class="stat total"><span>Total Records</span><b>${ins.total}</b></div><div class="stat flag"><span>Flagged</span><b>${ins.flagged.length}</b></div><div class="stat pending"><span>Pending &gt; 14 days</span><b>${ins.overdue}</b></div></div>
<div class="two"><section class="sec"><h3>BMI Distribution</h3>${bmi}</section><section class="sec"><h3>Flagged cases</h3><ul class="feed">${flags}</ul></section></div>` };
}
const pageName = (location.pathname.split('/').pop() || 'index.php').toLowerCase();
if (pageName === 'logout.php') { try { localStorage.removeItem('clinic-user'); } catch (e) {} location.replace('index.php'); }
const pageViews = { 'dashboard.php': 'dashboard', 'student-records.php': 'records', 'record-status.php': 'status', 'clearance-approval.php': 'clearance', 'record-analysis.php': 'analysis', 'insights.php': 'insights', 'profile.php': 'profile' };
if (pageViews[pageName]) view = pageViews[pageName];
try { const flash = sessionStorage.getItem('clinic-flash'); if (flash) { msg = flash; sessionStorage.removeItem('clinic-flash'); } } catch (e) {}
loadData().then(draw).then(async () => { if (view === 'insights' && me) { ins = await api('insights.php'); draw(); } }); // MYSQL: data comes from the database before the first draw
