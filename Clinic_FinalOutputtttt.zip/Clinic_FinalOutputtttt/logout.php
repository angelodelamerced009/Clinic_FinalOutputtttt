<?php
require_once __DIR__ . '/config.php';
// LOGOUT: isulat sa activity_logs, tapos tapusin ang PHP session.
if (!empty($_SESSION['user'])) {
    try { log_activity(db(), 'logout', $_SESSION['user']['full_name'] . ' logged out'); } catch (Throwable $e) { error_log('[clinic] logout log failed: ' . $e->getMessage()); }
}
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <title>Logout | School Clinic Management System</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Roboto+Condensed:wght@600;700&family=Syncopate:wght@700&display=swap">
  
</head>
<body>
  <div id="app"></div>
  <script src="js/main.js"></script>
</body>
</html>
