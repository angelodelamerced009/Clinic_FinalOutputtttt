import sys, json, re
from collections import Counter
from datetime import date, datetime, timedelta

rows = json.load(sys.stdin)          # records galing sa PHP

def bmi_of(h, w):
    if not h or not w:
        return None
    return round(w / ((h / 100) ** 2), 1)

def bmi_label(b):
    if b < 18.5: return "Underweight"
    if b < 25:   return "Normal"
    if b < 30:   return "Overweight"
    return "Obese"

def high_bp(bp):
    m = re.match(r"\s*(\d+)\s*/\s*(\d+)", bp or "")
    return bool(m) and (int(m[1]) >= 130 or int(m[2]) >= 85)

bmi_count, flagged, overdue = Counter(), [], 0
cutoff = date.today() - timedelta(days=14)

for r in rows:
    d = datetime.strptime(r["date"], "%Y-%m-%d").date()
    if r["status"] == "pending" and d < cutoff:
        overdue += 1

    reasons = []
    b = bmi_of(r.get("height"), r.get("weight"))
    if b is not None:
        lab = bmi_label(b)
        bmi_count[lab] += 1
        if lab in ("Underweight", "Obese"):
            reasons.append(f"BMI {b} ({lab})")
    if high_bp(r.get("bp")):
        reasons.append(f"Elevated BP {r['bp']}")
    if r.get("vision") and r["vision"].strip() != "20/20":
        reasons.append(f"Vision {r['vision']}")
    if reasons:
        flagged.append({"name": r["name"], "reason": "; ".join(reasons), "date": r["date"]})

n = sum(bmi_count.values())
bmi = [{"label": k, "count": bmi_count[k], "pct": round(100 * bmi_count[k] / n) if n else 0}
       for k in ["Underweight", "Normal", "Overweight", "Obese"]]

print(json.dumps({"ok": True, "total": len(rows), "overdue": overdue,
                  "flagged": flagged, "bmi": bmi}))
