-- OPTIONAL demo data (9 students + 9 medical records + activity log) so the dashboard is not empty.
-- Import ONCE, after database.sql (or after opening the PHP system once). Importing twice duplicates the records.
USE school_clinic_db;

INSERT IGNORE INTO students (student_no, full_name, year_level, course) VALUES
  ('CA202400125', 'Maria Santos', 'Year 2', 'BSIT'),
  ('CA202400127', 'Liam Garcia', 'Year 2', 'BSIT'),
  ('CA202400126', 'Ella Cruz', 'Year 1', 'BSN'),
  ('CA202400128', 'Juan Dela Cruz', 'Year 1', 'BSN'),
  ('CA202400129', 'Ana Reyes', 'Year 4', 'BSN'),
  ('CA202400130', 'Noah Bautista', 'Year 1', 'BSEd'),
  ('CA202400131', 'Angela Reyes', 'Year 3', 'BSEd'),
  ('CA202400132', 'Miguel Santos', 'Year 2', 'BSIT'),
  ('CA202400133', 'Sofia Ramirez', 'Year 3', 'BSN');

INSERT INTO medical_records (student_id, test_type, exam_date, status, remarks, height_cm, weight_kg, blood_pressure, heart_rate, vision, hearing, updated_at) VALUES
  ((SELECT id FROM students WHERE student_no = 'CA202400125'), 'Physical Exam', CURDATE() + INTERVAL 0 DAY, 'pending', 'Initial physical examination for school clearance.', 155, 48, '110/70', 72, '20/20', 'Normal', NOW() - INTERVAL 10 MINUTE),
  ((SELECT id FROM students WHERE student_no = 'CA202400127'), 'Dental Check-up', CURDATE() + INTERVAL 1 DAY, 'pending', 'Dental check-up follow-up.', 172, 66, '120/78', 74, '20/20', 'Normal', NOW() - INTERVAL 45 MINUTE),
  ((SELECT id FROM students WHERE student_no = 'CA202400126'), 'Vision Screening', CURDATE() + INTERVAL 2 DAY, 'pending', 'Vision screening follow-up.', 158, 50, '110/70', 68, '20/40', 'Normal', NOW() - INTERVAL 80 MINUTE),
  ((SELECT id FROM students WHERE student_no = 'CA202400128'), 'Immunization', CURDATE() + INTERVAL 3 DAY, 'ongoing', 'Immunization record updated.', 170, 64, '118/76', 78, '20/20', 'Normal', NOW() - INTERVAL 115 MINUTE),
  ((SELECT id FROM students WHERE student_no = 'CA202400129'), 'Dental Check-up', CURDATE() + INTERVAL 4 DAY, 'ongoing', 'Cleaning scheduled.', 160, 52, '112/72', 70, '20/20', 'Normal', NOW() - INTERVAL 150 MINUTE),
  ((SELECT id FROM students WHERE student_no = 'CA202400130'), 'Physical Exam', CURDATE() + INTERVAL 5 DAY, 'ongoing', 'Elevated blood pressure reading.', 168, 70, '138/88', 84, '20/20', 'Normal', NOW() - INTERVAL 185 MINUTE),
  ((SELECT id FROM students WHERE student_no = 'CA202400131'), 'Dental Check-up', CURDATE() + INTERVAL 6 DAY, 'approved', 'Dental check-up completed.', 162, 54, '108/68', 66, '20/20', 'Normal', NOW() - INTERVAL 220 MINUTE),
  ((SELECT id FROM students WHERE student_no = 'CA202400132'), 'Physical Exam', CURDATE() + INTERVAL 7 DAY, 'approved', 'No abnormalities detected.', 175, 72, '116/74', 72, '20/20', 'Normal', NOW() - INTERVAL 255 MINUTE),
  ((SELECT id FROM students WHERE student_no = 'CA202400133'), 'Immunization', CURDATE() + INTERVAL 8 DAY, 'approved', 'All doses complete.', 159, 51, '110/70', 70, '20/20', 'Normal', NOW() - INTERVAL 290 MINUTE);

INSERT INTO activity_logs (username, action, description, created_at) VALUES
  ('system', 'record_added', 'Maria Santos''s Physical Exam record added', NOW() - INTERVAL 10 MINUTE),
  ('system', 'record_added', 'Liam Garcia''s Dental Check-up record added', NOW() - INTERVAL 45 MINUTE),
  ('system', 'record_added', 'Ella Cruz''s Vision Screening record added', NOW() - INTERVAL 80 MINUTE),
  ('system', 'record_updated', 'Juan Dela Cruz''s Immunization record updated', NOW() - INTERVAL 115 MINUTE),
  ('system', 'record_updated', 'Ana Reyes''s Dental Check-up record updated', NOW() - INTERVAL 150 MINUTE),
  ('system', 'record_updated', 'Noah Bautista''s Physical Exam record updated', NOW() - INTERVAL 185 MINUTE),
  ('system', 'approved', 'Angela Reyes''s Dental Check-up approved', NOW() - INTERVAL 220 MINUTE),
  ('system', 'approved', 'Miguel Santos''s Physical Exam approved', NOW() - INTERVAL 255 MINUTE),
  ('system', 'approved', 'Sofia Ramirez''s Immunization approved', NOW() - INTERVAL 290 MINUTE);
